"""Pilot service catalog and bounded, read-only connection tests."""

from datetime import datetime, timezone
from copy import deepcopy
import http.client
import ipaddress
import json
import re
import ssl
import time
from urllib.parse import urlencode, urlsplit
from xml.etree import ElementTree


def _service(name, group, port, description, auth, read, configure, update, restore, docs,
             *, probe=False, required=False):
    return {
        "name": name,
        "ecosystem": group,
        "default_port": port,
        "description": description,
        "auth": auth,
        "probe_supported": probe,
        "credential_required": required,
        "documentation": docs,
        "capabilities": {"read": read, "configure": configure, "update": update,
                         "restore": restore},
    }


_SERVICES = {
    "plex": _service(
        "Plex Media Server", "Playback", 32400, "Library and playback server", "Plex token",
        "Server presence and active session count via the read-only Plex API.",
        "Library and server settings use the existing Plex Web App. Pilot changes are locked.",
        "Native Plex updater or the installed package's update path.",
        "Plex data directory and platform settings from a compatible backup.",
        "https://developer.plex.tv/pms/", probe=True),
    "sabnzbd": _service(
        "SABnzbd", "Download", 8080, "Usenet download client", "SABnzbd API key",
        "Read queue access and an aggregate queue count with an API key.",
        "Categories, paths and limits in the native UI. Pilot changes are locked.",
        "Existing installer or container image, after the queue is idle.",
        "Compatible application configuration backup with queue data handled separately.",
        "https://sabnzbd.org/wiki/configuration/5.1/api", probe=True, required=True),
    "qbittorrent": _service(
        "qBittorrent", "Download", 8080, "Torrent download client", "Web API key on qBittorrent 5.2+ or existing local read access",
        "Application and Web API versions. An existing local WebUI bypass may allow a tokenless check.",
        "Categories, limits and paths in the native WebUI. Pilot changes are locked.",
        "Existing installer or container image, after active work is reconciled.",
        "Application configuration and resume data from a compatible backup.",
        "https://github.com/qbittorrent/qBittorrent/wiki/WebUI-API-(qBittorrent-5.0)", probe=True),
    "bazarr": _service(
        "Bazarr", "Subtitles", 6767, "Subtitle availability and language profiles", "Bazarr API key",
        "Read system status and version.",
        "Subtitle providers and language profiles in Bazarr. Pilot changes are locked.",
        "Native installer or container update with a configuration backup.",
        "Native backup restore for a compatible Bazarr version.",
        "https://wiki.bazarr.media/", probe=True, required=True),
    "crosswatch": _service(
        "CrossWatch", "Playback", 8787, "Watch state synchronization", "Native sign-in",
        "Run history and snapshot summaries in the native UI. Pilot probe pending installed-version review.",
        "Sync pairs and directions in the native UI. Pilot changes are locked.",
        "Replace the container image with the active data volume preserved.",
        "Review native snapshots and their scope before any watch-state restore.",
        "https://wiki.crosswatch.app/"),
    "kometa": _service(
        "Kometa", "Maintenance", None, "Plex collections and metadata jobs", "Native job and logs",
        "Run logs and installed version from the existing job. Pilot probe unavailable.",
        "Collections and overlays use Kometa's own settings. Pilot changes are locked.",
        "Update the existing installation or image with the configuration retained.",
        "Restore the Kometa configuration bundle. Plex metadata recovery is separate.",
        "https://kometa.wiki/en/latest/kometa/install/files/"),
    "maintainerr": _service(
        "Maintainerr", "Maintenance", 6246, "Library maintenance rules", "No API key for the documented health endpoint",
        "Read local database health on versions with the readiness endpoint.",
        "Rules and collection actions in the native UI. Pilot changes are locked.",
        "Existing container image after a compatible data snapshot.",
        "Restore compatible application data and exported rules after checking dry-run scope.",
        "https://docs.maintainerr.info/api/app-and-health/", probe=True),
    "notifiarr": _service(
        "Notifiarr", "Notifications", 5454, "Notifications and local integration health", "Native sign-in and client credentials",
        "Read version and integration health in the client UI. Pilot probe pending installed-version review.",
        "Notification routing and endpoints in the native client. Pilot changes are locked.",
        "Existing client package or container image.",
        "Restore compatible client configuration. Cloud account state is separate.",
        "https://notifiarr.wiki/pages/client/system/"),
    "plex-auto-languages": _service(
        "Plex Auto Languages", "Playback", None, "Per-series audio and subtitle choices", "Native job and logs",
        "Run logs and image version from the existing job. Pilot probe unavailable.",
        "Language behavior uses the service's own settings. Pilot changes are locked.",
        "Update the existing image with the configuration retained.",
        "Restore service configuration. A Plex track selection restore would require separate review.",
        "https://github.com/RemiRigal/Plex-Auto-Languages"),
    "profilarr": _service(
        "Profilarr", "Quality", 6868, "Radarr and Sonarr profile synchronization", "Native sign-in",
        "Review linked profiles and sync history in Profilarr. Pilot probe pending installed-version review.",
        "Profile sync affects Radarr and Sonarr. Pilot changes are locked.",
        "Confirm major version compatibility before updating the existing image.",
        "Use a compatible application data snapshot. Existing Arr profiles have separate backups.",
        "https://github.com/Dictionarry-Hub/Profilarr"),
    "prowlarr": _service(
        "Prowlarr", "Release", 9696, "Indexer management", "Prowlarr API key",
        "Read application identity and version. No indexer requests are sent by this check.",
        "Indexer and application settings in Prowlarr. Pilot changes are locked.",
        "Native updater or pinned container image, depending on packaging.",
        "Native system backup restore on a compatible installation.",
        "https://prowlarr.com/docs/api/", probe=True, required=True),
    "radarr": _service(
        "Radarr", "Quality", 7878, "Movie release and import management", "Radarr API key",
        "Read application identity and version.",
        "Movie quality profiles and Custom Formats are previewed here. Pilot writes are locked.",
        "Native updater or pinned container image, depending on packaging.",
        "Native system backup restore on a compatible installation.",
        "https://radarr.video/docs/api/", probe=True, required=True),
    "seerr": _service(
        "Seerr", "Requests", 5055, "Movie and exact-episode request intake", "Seerr API key",
        "Read aggregate request counts.",
        "Request routing and permissions in the native UI. Pilot changes are locked.",
        "Existing package or pinned container image after a database backup.",
        "Restore compatible settings and SQLite or PostgreSQL data together.",
        "https://docs.seerr.dev/api/seerr-api/", probe=True, required=True),
    "sonarr": _service(
        "Sonarr", "Quality", 8989, "Series and episode release management", "Sonarr API key",
        "Read application identity and version on a supported API version.",
        "Series quality profiles and Custom Formats are previewed here. Pilot writes are locked.",
        "Native updater or pinned container image, depending on packaging.",
        "Native system backup restore on a compatible installation.",
        "https://sonarr.tv/docs/api/", probe=True, required=True),
    "tautulli": _service(
        "Tautulli", "Playback", 8181, "Playback evidence and history", "Tautulli API key",
        "Read aggregate playback activity. Viewer, media and session identifiers are discarded.",
        "Reporting and notifications in the native UI. Pilot changes are locked.",
        "Existing updater or image after config and database backup.",
        "Compatible native config and database recovery.",
        "https://docs.tautulli.com/extending-tautulli/api-reference", probe=True, required=True),
}


def service_catalog():
    return [{"id": service_id, **deepcopy(service)} for service_id, service in _SERVICES.items()]


def _status(state, detail, *, source="live", detected=False, connected=False,
            verified=False, checked_at=None, version=None, **counts):
    return {"state": state, "detail": detail, "source": source, "detected": detected,
            "connected": connected, "verified": verified, "checked_at": checked_at,
            "version": version, **counts}


def fixture_statuses():
    rows = {}
    for service_id, service in _SERVICES.items():
        if not service["probe_supported"]:
            rows[service_id] = _status("manual", "Fixture only. Registered for manual review.", source="fixture")
        else:
            rows[service_id] = _status("verified", "Fixture only. Sample read response verified.", source="fixture",
                                       detected=True, connected=True, verified=True)
    rows["plex"]["active_sessions"] = 1
    rows["notifiarr"]["detected"] = True
    rows["notifiarr"]["detail"] = "Fixture only. Simulated installed client with no pilot API check."
    rows["bazarr"] = _status("unavailable", "Fixture only. Simulated endpoint unavailable.", source="fixture")
    return rows


_LOCAL_NETWORKS = tuple(ipaddress.ip_network(network) for network in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "fc00::/7",
))
_PATH_PREFIX = re.compile(r"(?:/[A-Za-z0-9_-]+)*/?")
_VERSION = re.compile(r"v?\d+(?:\.\d+){1,4}(?:[-+][A-Za-z0-9._+-]{1,38})?")
_MAX_RESPONSE = 256 * 1024


def validate_base_url(base_url):
    error = "Use a loopback or private LAN IP address with HTTP or HTTPS."
    if not isinstance(base_url, str) or len(base_url) > 512:
        raise ValueError(error)
    base_url = base_url.strip()
    if any(ord(char) <= 32 or ord(char) >= 127 for char in base_url) or any(
        char in base_url for char in "\\?#%"
    ):
        raise ValueError(error)
    try:
        parsed = urlsplit(base_url)
        port = parsed.port
        host = parsed.hostname
        address = ipaddress.ip_address("127.0.0.1" if host == "localhost" else host)
        if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped is not None:
            address = address.ipv4_mapped
    except (ValueError, TypeError):
        raise ValueError(error) from None
    if (parsed.scheme not in {"http", "https"} or parsed.username is not None or
            parsed.password is not None or port == 0 or not _PATH_PREFIX.fullmatch(parsed.path) or
            (not address.is_loopback and not any(address in network for network in _LOCAL_NETWORKS))):
        raise ValueError(error)
    normalized_host = f"[{address}]" if address.version == 6 else str(address)
    authority = f"{normalized_host}:{port}" if port is not None else normalized_host
    return f"{parsed.scheme}://{authority}{parsed.path.rstrip('/')}"


def validate_connection(base_url, credential=""):
    base_url = validate_base_url(base_url)
    if (not isinstance(credential, str) or len(credential) > 2048 or
            any(ord(char) < 33 or ord(char) > 126 for char in credential)):
        raise ValueError("Enter a valid API key or token.")
    target = urlsplit(base_url)
    if credential and target.scheme == "http" and not ipaddress.ip_address(target.hostname).is_loopback:
        raise ValueError("Connections with credentials require HTTPS on the LAN or HTTP on this PC's loopback address.")
    return base_url


def _read(base_url, path, headers, timeout, query=None):
    target = urlsplit(base_url)
    connection_type = http.client.HTTPSConnection if target.scheme == "https" else http.client.HTTPConnection
    connection = connection_type(target.hostname, target.port, timeout=timeout)
    request_path = target.path + path
    if query:
        request_path += "?" + urlencode(query)
    deadline = time.monotonic() + timeout
    try:
        connection.connect()
        network_socket = connection.sock
        connection.request("GET", request_path, headers={"Accept": "application/json", **headers})
        with connection.getresponse() as response:
            if response.status != 200:
                return response.status, b""
            if response.length is not None and response.length > _MAX_RESPONSE:
                return response.status, b""
            body = bytearray()
            while len(body) <= _MAX_RESPONSE:
                if response.isclosed() or response.length == 0:
                    return response.status, bytes(body)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError()
                network_socket.settimeout(remaining)
                chunk = response.read1(min(8192, _MAX_RESPONSE + 1 - len(body)))
                if not chunk:
                    return response.status, bytes(body)
                body.extend(chunk)
            return response.status, b""
    finally:
        connection.close()


def _dict(value):
    return value if isinstance(value, dict) else {}


def _json(body):
    try:
        return _dict(json.loads(body))
    except (ValueError, RecursionError):
        return {}


def _version(value):
    if isinstance(value, str) and _VERSION.fullmatch(value):
        return value
    return None


def _count(value):
    if type(value) is int and 0 <= value < 10**9:
        return value
    if isinstance(value, str) and re.fullmatch(r"[0-9]{1,9}", value):
        return int(value)
    return None


def _plex_container(body):
    container = _dict(_json(body).get("MediaContainer"))
    if container or not body.lstrip().startswith(b"<") or b"<!" in body or b"\x00" in body:
        return container
    try:
        root = ElementTree.fromstring(body)
    except (ElementTree.ParseError, ValueError):
        return {}
    return root.attrib if root.tag == "MediaContainer" else {}


def _parse_response(service_id, body, identity):
    data = _json(body)
    if service_id == "plex":
        container = _plex_container(body)
        if identity:
            version = _version(container.get("version"))
            return {"version": version} if version and container.get("machineIdentifier") else None
        count = _count(container.get("size"))
        return {"active_sessions": count} if count is not None else None
    if service_id in {"radarr", "sonarr", "prowlarr"}:
        version = _version(data.get("version"))
        return {"version": version} if version and str(data.get("appName")).lower() == service_id else None
    if service_id == "bazarr":
        version = _version(_dict(data.get("data")).get("bazarr_version") or data.get("bazarr_version"))
        return {"version": version} if version else None
    if service_id == "sabnzbd":
        queue = _dict(data.get("queue"))
        count = _count(queue.get("noofslots_total"))
        if _version(queue.get("version")) and count is not None:
            return {"version": queue["version"], "queue_count": count}
    if service_id == "maintainerr" and data.get("status") == "ok" and data.get("database") == "ok":
        if _count(data.get("uptimeSeconds")) is not None and isinstance(data.get("timestamp"), str):
            return {}
    if service_id == "seerr" and all(_count(data.get(key)) is not None for key in ("total", "movie", "tv", "pending")):
        return {"request_count": _count(data["total"])}
    if service_id == "tautulli":
        response = _dict(data.get("response"))
        activity = _dict(response.get("data"))
        count = _count(activity.get("stream_count"))
        direct = _count(activity.get("stream_count_direct_play"))
        if response.get("result") == "success" and count is not None and direct is not None:
            return {"active_sessions": count, "direct_play_sessions": direct}
    return None


def _http_status(code, checked_at):
    detail = f"Local endpoint replied with HTTP {code}."
    if code in {401, 403}:
        detail = "Local endpoint denied the read. Check the registered API credential and service access."
    elif 300 <= code < 400:
        detail = "Local endpoint redirected the read. Register the final local service address."
    return _status("unavailable" if code >= 500 else "detected", detail,
                   detected=True, checked_at=checked_at)


_GETS = {
    "plex": ("/status/sessions", "X-Plex-Token"),
    "sabnzbd": ("/api", None),
    "qbittorrent": ("/api/v2/app/version", "Authorization"),
    "bazarr": ("/api/system/status", "X-Api-Key"),
    "maintainerr": ("/api/health/ready", None),
    "prowlarr": ("/api/v1/system/status", "X-Api-Key"),
    "radarr": ("/api/v3/system/status", "X-Api-Key"),
    "seerr": ("/api/v1/request/count", "X-Api-Key"),
    "sonarr": ("/api/v3/system/status", "X-Api-Key"),
    "tautulli": ("/api/v2", None),
}


def probe_service(service_id, base_url, credential="", *, timeout=2.0):
    """Read only considered endpoints. Return no raw response or user data."""
    if service_id not in _SERVICES:
        raise ValueError("Unknown service.")
    service = _SERVICES[service_id]
    if not service["probe_supported"]:
        return _status("manual", "Registered for manual review. Automated verification is unavailable.", source="none")
    if not base_url:
        return _status("unconfigured", "Enter a service URL in Manage to run a connection test.", source="none")
    base_url = validate_connection(base_url, credential)
    if service["credential_required"] and not credential:
        return _status("credential_needed", f"Enter a {service['auth']} to run the read test.", source="none")
    path, header = _GETS[service_id]
    identity = service_id == "plex" and not credential
    if identity:
        path = "/identity"
    headers = {header: credential} if header and credential else {}
    query = None
    if service_id == "qbittorrent" and credential:
        headers["Authorization"] = f"Bearer {credential}"
    if service_id == "sabnzbd":
        query = {"mode": "queue", "output": "json", "limit": 1, "apikey": credential}
    if service_id == "tautulli":
        query = {"cmd": "get_activity", "apikey": credential}
    checked_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    try:
        code, body = _read(base_url, path, headers, timeout, query)
        if code == 404 and service_id == "sonarr":
            code, body = _read(base_url, "/api/v5/system/status", headers, timeout)
        if code != 200:
            return _http_status(code, checked_at)
        if service_id == "qbittorrent":
            version = _version(body.decode("ascii", errors="replace").strip())
            api_code, api_body = _read(base_url, "/api/v2/app/webapiVersion", headers, timeout)
            api_version = _version(api_body.decode("ascii", errors="replace").strip())
            result = {"version": version} if version and api_code == 200 and api_version else None
        else:
            result = _parse_response(service_id, body, identity)
    except ssl.SSLCertVerificationError:
        return _status("unavailable", "The service TLS certificate did not validate.", checked_at=checked_at)
    except (OSError, ValueError, http.client.HTTPException):
        return _status("unavailable", "Local read timed out or the endpoint could not be reached.", checked_at=checked_at)
    if result is None:
        return _status("connected", "The local endpoint answered. The service response could not be verified.",
                       detected=True, connected=True, checked_at=checked_at)
    if credential and result.get("version") == credential:
        result.pop("version")
    if identity:
        return _status("detected", "Plex identity detected. A Plex token is needed to verify a playback read.",
                       detected=True, checked_at=checked_at, **result)
    detail = "Live read verified."
    if service_id == "qbittorrent" and not credential:
        detail = "Live read verified using the WebUI's existing local access."
    return _status("verified", detail, detected=True, connected=True, verified=True,
                   checked_at=checked_at, **result)
