"""Local-only PMI preview. Every external request is owned by the probe registry."""

from __future__ import annotations

import argparse
from hashlib import sha256
import hmac
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
from queue import Empty, Queue
import secrets
import socket
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import urlsplit
import webbrowser

from pilot_quality import get_quality_preview
from pilot_services import fixture_statuses, playback_coach, probe_service, remember_playback, service_catalog, validate_connection
from pilot_vault import decrypt, encrypt
from pmi_capabilities import M1_CAPABILITIES, M1_EXTERNAL_MUTATION_ENABLED
from qnap_probe import (
    RESERVE_BYTES,
    is_pmi_service_account,
    probe_share,
    validate_storage_credentials,
    validate_storage_share,
)


VERSION = "0.1.1-windows-service-pilot"
SERVICE_PRODUCT = "pmi-windows-service"
WEB = Path(__file__).resolve().parent / "web"
ASSET_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".jpg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
}
CATALOG = {service["id"]: service for service in service_catalog()}
FIXTURES = fixture_statuses()
REFRESH_SECONDS = 300
STALE_SECONDS = 2 * REFRESH_SECONDS
SESSION_SECONDS = 8 * 3600
QNAP_JOB = "QNAP read check"
QNAP_ERROR_DETAILS = {
    "identity": "The probe could not verify the PMI Windows service account.",
    "configuration": "The configured QNAP share is unavailable for measurement.",
    "credential": "Windows could not unlock the saved credential. Re-enter it in Manage.",
    "logon": "Windows could not create an SMB logon for the saved credential.",
    "impersonation": "Windows could not use the dedicated SMB credential.",
    "list": "The service could not list the root of Multimedia.",
    "space": "Windows could not query free space for Multimedia.",
    "revert": "Windows could not finish the isolated SMB check.",
    "timeout": "The QNAP storage check timed out.",
    "worker": "The isolated QNAP storage probe failed.",
}
PRISM = {
    "status": "Isolated",
    "detail": "The Plex pilot has its own process and data directory. No PRISM bindings or shared state.",
}
RECOMMENDATIONS = [
    {"title": "The Silent Meridian", "year": 2026, "kind": "Movie",
     "reason": "A slow-burn wilderness mystery."},
    {"title": "Outpost Nine", "year": 2025, "kind": "Series",
     "reason": "An isolated station and a signal from the storm."},
    {"title": "Below the Waterline", "year": 2024, "kind": "Movie",
     "reason": "A cinematic deep-water expedition."},
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def pending_status(detail: str) -> dict:
    return {
        "detected": None, "connected": None, "verified": None, "source": "none",
        "state": "pending", "detail": detail, "checked_at": None, "version": None,
    }


def observed_status(result: dict) -> dict:
    """Snapshots retain their evidence date and disclose when a probe is due."""
    observed = result.copy()
    checked_at = observed.get("checked_at")
    if checked_at and (observed.get("source") == "live" or observed.get("evidence") == "live"):
        try:
            age = datetime.now(timezone.utc) - datetime.fromisoformat(checked_at)
        except (ValueError, TypeError):
            observed["stale"] = True
        else:
            observed["stale"] = age.total_seconds() < 0 or age >= timedelta(seconds=STALE_SECONDS)
    return observed


def unverified_storage(status: str, detail: str, *, checked_at: str | None = None) -> dict:
    return {
        "evidence": "none", "reserve_tb": 2, "reserve_status": "unverified",
        "free_tb": None, "checked_at": checked_at, "status": status, "detail": detail,
    }


class Pilot:
    def __init__(self, data_dir: Path, *, refresh_seconds=REFRESH_SECONDS,
                 manage_hash: bytes | None = None, qnap_share: str | None = None,
                 updates=None, version: str = VERSION, instance: str | None = None):
        self.lock = threading.RLock()
        self.refresh_seconds = refresh_seconds
        data_dir.mkdir(parents=True, exist_ok=True)
        self.instance_lock = (data_dir / "instance.lock").open("a+b")
        if os.name == "nt":
            import msvcrt
            self.instance_lock.seek(0)
            try:
                msvcrt.locking(self.instance_lock.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                self.instance_lock.close()
                raise RuntimeError("The local pilot is already running.") from None
        self.connection = sqlite3.connect(data_dir / "pilot.sqlite3", check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS service (
                id TEXT PRIMARY KEY, url TEXT NOT NULL,
                secret BLOB, revision TEXT NOT NULL, status TEXT
            );
            CREATE TABLE IF NOT EXISTS preferences (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS qnap_storage (
                id INTEGER PRIMARY KEY CHECK (id=1),
                share TEXT NOT NULL, secret BLOB NOT NULL, revision TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS job_log (
                seq INTEGER PRIMARY KEY, job TEXT NOT NULL, at TEXT NOT NULL, outcome TEXT NOT NULL
            );
        """)
        self.connections = {
            row["id"]: dict(row) for row in self.connection.execute("SELECT * FROM service")
            if row["id"] in CATALOG
        }
        saved = self.connection.execute(
            "SELECT value FROM preferences WHERE key = 'recommendations'"
        ).fetchone()
        self.opt_in = saved is not None and saved[0] == "1"
        self.quality = get_quality_preview()
        self.code = secrets.token_urlsafe(12) if manage_hash is None else None
        self.service_mode = manage_hash is not None
        self.updates = updates if self.service_mode else None
        self.version = version
        self.instance = instance
        self.manage_hash = sha256(self.code.encode("ascii")).digest() if self.code else manage_hash
        self.qnap_share = None
        if self.service_mode and qnap_share and is_pmi_service_account():
            try:
                self.qnap_share = validate_storage_share(qnap_share)
            except ValueError:
                pass
        saved_qnap = self.connection.execute(
            "SELECT secret, revision FROM qnap_storage WHERE id=1 AND share=?",
            (self.qnap_share,),
        ).fetchone()
        self.qnap_config = dict(saved_qnap) if saved_qnap else None
        self.storage = self._pending_qnap_storage()
        self.sessions: dict[str, float] = {}
        self.failed_unlocks: list[float] = []
        self.jobs: Queue[tuple[str, str | None, str | None]] = Queue()
        self.scheduled: set[tuple[str, str | None, str | None]] = set()
        self.active: str | None = None
        self.stop = threading.Event()
        self.worker: threading.Thread | None = None

    def start(self) -> None:
        self.worker = threading.Thread(target=self._work, name="PMI shared scheduler", daemon=True)
        self.worker.start()

    def close(self) -> None:
        self.stop.set()
        if self.worker is not None:
            self.worker.join()
        self.connection.close()
        self.instance_lock.close()

    def enqueue(self, kind: str, service_id: str | None = None) -> bool:
        with self.lock:
            configured = self.qnap_config if kind == QNAP_JOB else self.connections.get(service_id)
            if kind == QNAP_JOB and not configured:
                return False
            if service_id and (not configured or not CATALOG[service_id]["probe_supported"]):
                return False
            revision = configured["revision"] if configured else None
            item = (kind, service_id, revision)
            if item not in self.scheduled:
                self.scheduled.add(item)
                self.jobs.put(item)
            return True

    def _schedule(self) -> None:
        with self.lock:
            self.enqueue(QNAP_JOB)
            for service_id in self.connections:
                self.enqueue("Connection check", service_id)
            self.enqueue("Playback & Quality")
            self.enqueue("Release & Import")
            self.enqueue("Maintenance")
            self.enqueue("Recommendations")

    def _work(self) -> None:
        # Refresh starts after the HTTP listener is ready. HTTP reads only saved state.
        next_refresh = time.monotonic()
        while not self.stop.is_set():
            if time.monotonic() >= next_refresh:
                self._schedule()
                next_refresh = time.monotonic() + self.refresh_seconds
            try:
                item = self.jobs.get(timeout=0.2)
            except Empty:
                continue
            kind, service_id, revision = item
            label = CATALOG[service_id]["name"] + " connection" if service_id else kind
            with self.lock:
                self.active = label
            try:
                outcome = self._run_job(kind, service_id, revision)
            except Exception:
                # A failed job must not take down subsequent observations or leak provider data.
                outcome = "Job failed. Existing evidence is retained."
            finally:
                with self.lock, self.connection:
                    self.active = None
                    self.scheduled.discard(item)
                    self.connection.execute(
                        "INSERT INTO job_log (job, at, outcome) VALUES (?, ?, ?)",
                        (label, utc_now(), outcome),
                    )
                    self.connection.execute(
                        "DELETE FROM job_log WHERE seq <= (SELECT MAX(seq)-100 FROM job_log)"
                    )
                self.jobs.task_done()

    def _run_job(self, kind: str, service_id: str | None, revision: str | None) -> str:
        if kind == QNAP_JOB:
            return self._read_qnap_storage(revision)

        if service_id:
            with self.lock:
                config = self.connections.get(service_id)
                if not config or config["revision"] != revision:
                    return "Superseded by changed setup."
            try:
                secret = decrypt(config["secret"]) if config["secret"] else ""
            except OSError:
                result = pending_status("Windows could not unlock the saved credential. Re-enter it in Manage.")
            else:
                result = probe_service(service_id, config["url"], secret)
            with self.lock, self.connection:
                latest = self.connections.get(service_id)
                if not latest or latest["revision"] != revision:
                    return "Superseded by changed setup."
                remember_playback(service_id, result, latest["status"])
                status = json.dumps(result)
                self.connection.execute(
                    "UPDATE service SET status=? WHERE id=? AND revision=?", (status, service_id, revision),
                )
                self.connections[service_id] = {**latest, "status": status}
            return result["state"] + " · " + result["source"]

        if kind == "Playback & Quality":
            preview = get_quality_preview()
            with self.lock:
                self.quality = preview
            return "Evaluated device compatibility and readiness · fixture"
        if kind == "Release & Import":
            with self.lock:
                return " / ".join(trace["outcome"].replace("_", " ") for trace in self.quality["traces"]) + " · fixture"
        if kind == "Maintenance":
            with self.lock:
                if self.service_mode:
                    return f"2 TB reserve · {self._storage_snapshot()['status']}"
                storage = self.quality["policy"].get("storage", {})
            return f"Reserve floor {storage.get('reserve_tb', 2)} TB · fixture"
        with self.lock:
            return "List opt-in enabled for preview only." if self.opt_in else "Suggestions only."

    def _pending_qnap_storage(self) -> dict:
        if not self.qnap_share:
            return unverified_storage("QNAP setup unavailable", "QNAP Storage requires the PMI Windows service and its configured Multimedia share.")
        if not self.qnap_config:
            return unverified_storage("QNAP credential needed", "Save a dedicated read-only SMB credential in Manage.")
        return unverified_storage("Awaiting QNAP measurement", "PMI is waiting for a read-only measurement from the Windows service.")

    def _storage_snapshot(self) -> dict:
        result = observed_status(self.storage)
        if result.get("stale"):
            result = {
                **unverified_storage("QNAP measurement expired", "Waiting for a current service-account measurement.",
                                     checked_at=result["checked_at"]),
                "stale": True,
            }
        return result

    def _read_qnap_storage(self, revision: str | None) -> str:
        with self.lock:
            config = self.qnap_config
            if not config or config["revision"] != revision:
                return "Superseded by changed QNAP setup."
        try:
            measured = probe_share(self.qnap_share, config["secret"])
            if measured.get("evidence") == "live":
                available = measured.get("available_bytes")
                free = measured.get("reported_free_bytes")
                checked_at = datetime.fromisoformat(measured["checked_at"])
                age = datetime.now(timezone.utc) - checked_at
                if not (
                    measured.get("service_identity_verified") is True and measured.get("read_verified") is True
                    and type(available) is int and type(free) is int and min(available, free) >= 0
                    and timedelta(0) <= age
                ):
                    raise ValueError("Incomplete storage evidence.")
                usable_free = min(available, free)
                met = usable_free >= RESERVE_BYTES
                result = {
                    "evidence": "live", "reserve_tb": 2, "reserve_status": "met" if met else "below",
                    "available_bytes": available, "reported_free_bytes": free,
                    "free_tb": usable_free / 10**12, "checked_at": checked_at.isoformat(),
                    "status": "2 TB reserve met" if met else "2 TB reserve below threshold",
                    "detail": "Measured by the PMI Windows service with the dedicated SMB credential.",
                }
            else:
                detail = QNAP_ERROR_DETAILS.get(measured.get("error_stage"), "The service could not verify QNAP free space.")
                code = measured.get("error_code")
                if type(code) is int and 0 < code <= 0xFFFFFFFF:
                    detail += f" Windows error {code}."
                result = unverified_storage("QNAP measurement unsuccessful", detail, checked_at=utc_now())
        except Exception:
            result = unverified_storage("QNAP measurement unsuccessful", "The service could not obtain valid QNAP evidence.",
                                        checked_at=utc_now())
        with self.lock:
            latest = self.qnap_config
            if not latest or latest["revision"] != revision:
                return "Superseded by changed QNAP setup."
            self.storage = result
        return result["status"]

    def _status(self, service_id: str) -> dict:
        config = self.connections.get(service_id)
        if not config:
            return FIXTURES[service_id].copy()
        if config["status"]:
            return observed_status(json.loads(config["status"]))
        if not CATALOG[service_id]["probe_supported"]:
            return pending_status("Local setup saved. This service needs a supported evidence adapter.")
        return pending_status("Setup saved. The first connection check is pending.")

    def snapshot(self, unlocked: bool) -> dict:
        with self.lock:
            watch = {"evidence": "fixture", "plex_url": None, "playing": [], "status": "Fixture catalog"}
            playback = {name: self._status(name) for name in ("plex", "tautulli") if name in self.connections}
            plex = playback.get("plex")
            if plex:
                if plex["source"] == "live" and plex["detected"] and not plex.get("stale"):
                    watch["plex_url"] = self.connections["plex"]["url"] + "/web"
                if plex["source"] == "live" and plex["verified"] and "active_sessions" in plex:
                    watch["plex_activity"] = {
                        "evidence": "live", "checked_at": plex["checked_at"],
                        "active_sessions": plex["active_sessions"], "stale": plex.get("stale", False),
                    }
            watch["playback_coach"] = playback_coach(playback, stale_after=timedelta(seconds=STALE_SECONDS))
            result = {
                "mode": "read-only",
                "manage_prompt": (
                    "Enter the Manage code from Windows Setup." if self.service_mode else
                    "Enter the access code shown in the window that started the local preview."
                ),
                "manage_unlocked": unlocked,
                "watch": watch,
                "recommendations": {
                    "evidence": "fixture", "enabled": self.opt_in, "items": RECOMMENDATIONS,
                },
            }
            if unlocked:
                services = []
                for service_id, service in CATALOG.items():
                    configured = self.connections.get(service_id)
                    status = playback[service_id].copy() if service_id in playback else self._status(service_id)
                    status.pop("playback_cache", None)
                    services.append({
                        **service, **status, "evidence": status["source"],
                        "url": configured["url"] if configured else "",
                        "has_secret": bool(configured and configured["secret"]),
                        "queued": any(job[1] == service_id for job in self.scheduled),
                    })
                result.update({
                    "services": services,
                    "updates": self.updates.snapshot() if self.updates else {
                        "configured": False, "current_version": self.version,
                        "previous_version": None, "available_version": None,
                        "phase": "unavailable", "rollback": None,
                        "detail": "Set up the updater on the PMI Windows service.",
                    },
                    "quality": self.quality,
                    "scheduler": {
                        "worker_limit": 1, "active": self.active, "queued": self.jobs.qsize(),
                        "refresh_seconds": self.refresh_seconds,
                        "recent": [dict(row) for row in self.connection.execute(
                            "SELECT job, at, outcome FROM job_log ORDER BY seq DESC LIMIT 10"
                        )],
                    },
                    "qnap_storage": {
                        "supported": self.qnap_share is not None,
                        "configured": self.qnap_config is not None,
                        "share": self.qnap_share,
                    },
                    "storage": self._storage_snapshot() if self.service_mode else {
                        "evidence": "fixture", "reserve_tb": self.quality["policy"]["reserve_tb"],
                        "free_tb": self.quality["policy"]["storage"]["qnap_free_gb"] / 1000,
                        "reserve_status": "unverified",
                        "status": "Reserve enforced in simulation",
                        "detail": "QNAP capacity is simulated. No media volume is mounted or written by the pilot.",
                    },
                    "prism": PRISM,
                })
            return result

    def configure_qnap(self, username: str, password: str, *, read_only_confirmed: bool) -> None:
        if not self.qnap_share or not is_pmi_service_account():
            raise ValueError("Save QNAP credentials in Manage on the PMI Windows service.")
        if read_only_confirmed is not True:
            raise ValueError("Confirm this is a dedicated read-only account for Multimedia.")
        username, password = validate_storage_credentials(username, password)
        sealed = encrypt(json.dumps({"username": username, "password": password}))
        revision = secrets.token_hex(12)
        with self.lock:
            with self.connection:
                self.connection.execute(
                    "INSERT OR REPLACE INTO qnap_storage (id, share, secret, revision) VALUES (1, ?, ?, ?)",
                    (self.qnap_share, sealed, revision),
                )
            self.qnap_config = {"secret": sealed, "revision": revision}
            self.storage = self._pending_qnap_storage()
            self.enqueue(QNAP_JOB)

    def forget_qnap(self) -> None:
        if not self.qnap_share or not is_pmi_service_account():
            raise ValueError("Manage QNAP credentials on the PMI Windows service.")
        with self.lock:
            with self.connection:
                self.connection.execute("DELETE FROM qnap_storage WHERE id=1 AND share=?", (self.qnap_share,))
            self.qnap_config = None
            self.storage = self._pending_qnap_storage()

    def configure(self, service_id: str, url: str, secret: str) -> None:
        base_url = validate_connection(url, secret)
        with self.lock, self.connection:
            old = self.connections.get(service_id)
            if not secret and old and old["secret"] and old["url"] != base_url:
                raise ValueError("Enter the credential again to change a saved service address, or remove the setup first.")
            encrypted = encrypt(secret) if secret else old["secret"] if old else None
            revision = secrets.token_hex(12)
            self.connection.execute(
                "INSERT OR REPLACE INTO service (id, url, secret, revision, status) VALUES (?, ?, ?, ?, NULL)",
                (service_id, base_url, encrypted, revision),
            )
            self.connections[service_id] = {
                "id": service_id, "url": base_url, "secret": encrypted, "revision": revision, "status": None,
            }
            self.enqueue("Connection check", service_id)

    def forget(self, service_id: str) -> None:
        with self.lock, self.connection:
            self.connection.execute("DELETE FROM service WHERE id=?", (service_id,))
            self.connections.pop(service_id, None)

    def set_preference(self, enabled: bool) -> None:
        with self.lock, self.connection:
            self.connection.execute(
                "INSERT OR REPLACE INTO preferences (key, value) VALUES ('recommendations', ?)",
                ("1" if enabled else "0",),
            )
            self.opt_in = enabled

    def unlock(self, code: str) -> str | None:
        with self.lock:
            now = time.monotonic()
            self.failed_unlocks = [attempt for attempt in self.failed_unlocks if now - attempt < 60]
            if len(self.failed_unlocks) >= 8:
                return None
            if not hmac.compare_digest(sha256(code.encode("utf-8")).digest(), self.manage_hash):
                self.failed_unlocks.append(now)
                return None
            self.sessions = {session: expiry for session, expiry in self.sessions.items() if expiry > now}
            session = secrets.token_urlsafe(32)
            self.sessions[session] = now + SESSION_SECONDS
            return session

    def authorized(self, session: str) -> bool:
        with self.lock:
            return self.sessions.get(session, 0) > time.monotonic()


class Server(ThreadingHTTPServer):
    # On Windows a second process must never bind the same preview port.
    allow_reuse_address = False

    def server_bind(self) -> None:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

    @property
    def origin(self) -> str:
        return f"http://127.0.0.1:{self.server_port}"


class Handler(BaseHTTPRequestHandler):
    server: Server

    def setup(self) -> None:
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *_args) -> None:
        pass

    def _send(self, status: int, data: bytes, content_type: str, extra_headers=()) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        ))
        for key, value in extra_headers:
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def _json(self, status: int, value: dict, extra_headers=()) -> None:
        self._send(status, json.dumps(value).encode("utf-8"), "application/json", extra_headers)

    def _session(self) -> str:
        try:
            cookies = SimpleCookie(self.headers.get("Cookie", ""))
            return cookies["pmi_manage"].value if "pmi_manage" in cookies else ""
        except (ValueError, CookieError):
            return ""

    def _allowed_host(self) -> bool:
        if self.headers.get("Host") == self.server.origin.removeprefix("http://"):
            return True
        self._json(403, {"error": "Use the numeric loopback address for this dashboard."})
        return False

    def do_GET(self) -> None:
        if not self._allowed_host():
            return
        path = urlsplit(self.path).path
        pilot = self.server.pilot
        if path == "/api/ready":
            ready = pilot.service_mode and pilot.worker is not None and pilot.worker.is_alive()
            report = {
                "product": SERVICE_PRODUCT, "version": pilot.version, "mode": "read-only", "ready": ready,
            }
            if pilot.instance is not None:
                report["instance"] = pilot.instance
            self._json(200 if ready else 503, report)
            return
        if path == "/api/snapshot":
            self._json(200, pilot.snapshot(pilot.authorized(self._session())))
            return
        if path == "/api/v1/capabilities":
            self._json(200, {"mode": "read_only", "external_mutation_enabled": M1_EXTERNAL_MUTATION_ENABLED,
                             "capabilities": M1_CAPABILITIES, "version": pilot.version})
            return
        relative = {"": "index.html", "watch": "index.html", "manage": "index.html"}.get(
            path.lstrip("/"), path.lstrip("/")
        )
        target = (WEB / relative).resolve()
        mime_type = ASSET_TYPES.get(target.suffix.lower())
        if not mime_type or not target.is_relative_to(WEB) or not target.is_file():
            self._json(404, {"error": "Page unavailable."})
            return
        self._send(200, target.read_bytes(), mime_type)

    def do_POST(self) -> None:
        self._write()

    def do_DELETE(self) -> None:
        self._write()

    def _read_json(self) -> dict:
        size = int(self.headers.get("Content-Length", 0))
        if not size:
            return {}
        if size < 0 or size > 8192 or self.headers.get_content_type() != "application/json":
            raise ValueError("Use a JSON request smaller than 8 KB.")
        data = json.loads(self.rfile.read(size))
        if not isinstance(data, dict):
            raise ValueError("Use a JSON object.")
        return data

    def _write(self) -> None:
        if not self._allowed_host():
            return
        if self.headers.get("Origin") != self.server.origin:
            self._json(403, {"error": "Open Manage from the local pilot website."})
            return
        path = urlsplit(self.path).path
        is_post = self.command == "POST"
        session = self._session()
        pilot = self.server.pilot
        try:
            if path == "/api/unlock" and is_post:
                code = self._read_json().get("code")
                token = pilot.unlock(code.strip()) if isinstance(code, str) else None
                if token:
                    self._json(200, {"ok": True}, [("Set-Cookie",
                        f"pmi_manage={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_SECONDS}")])
                else:
                    self._json(403, {"error": "Use the current Manage code. After repeated attempts, wait one minute."})
                return
            if not pilot.authorized(session):
                self._json(401, {"error": "Unlock Manage first."})
                return
            if path == "/api/lock" and is_post:
                with pilot.lock:
                    pilot.sessions.pop(session, None)
                self._json(200, {"ok": True}, [("Set-Cookie",
                    "pmi_manage=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0")])
                return
            if pilot.updates and pilot.updates.trial_active():
                self._json(409, {"error": "Manage settings are read-only during update health checks."})
                return
            if path == "/api/updates/policy" and is_post:
                if not pilot.updates:
                    self._json(409, {"error": "Set up the updater on the PMI Windows service."})
                    return
                body = self._read_json()
                if set(body) != {"enabled", "paused", "start", "end"}:
                    raise ValueError("Provide automatic updates, pause, and both UTC window times.")
                pilot.updates.save_policy(body)
                self._json(200, {"ok": True})
                return
            if path == "/api/updates/rollback" and is_post:
                if not pilot.updates:
                    self._json(409, {"error": "Set up the updater on the PMI Windows service."})
                    return
                if self._read_json():
                    raise ValueError("Use an empty request for rollback.")
                pilot.updates.request_rollback()
                self._json(202, {"ok": True})
                return
            if path == "/api/recommendations/opt-in" and is_post:
                enabled = self._read_json().get("enabled")
                if not isinstance(enabled, bool):
                    raise ValueError("Choose whether to include this list in preview evaluations.")
                pilot.set_preference(enabled)
                self._json(200, {"ok": True})
                return
            if path == "/api/qnap/storage":
                if is_post:
                    body = self._read_json()
                    if set(body) != {"username", "password", "read_only_confirmed"}:
                        raise ValueError("Enter the QNAP credential and confirm its read-only access.")
                    pilot.configure_qnap(body["username"], body["password"],
                                         read_only_confirmed=body["read_only_confirmed"])
                else:
                    pilot.forget_qnap()
                self._json(200, {"ok": True})
                return
            parts = path.strip("/").split("/")
            if len(parts) == 4 and parts[:2] == ["api", "services"] and parts[2] in CATALOG:
                service_id, action = parts[2:]
                if action == "credentials":
                    if is_post:
                        body = self._read_json()
                        url, secret = body.get("url"), body.get("secret", "")
                        if not isinstance(url, str) or not isinstance(secret, str):
                            raise ValueError("Enter a service address and an optional credential.")
                        pilot.configure(service_id, url, secret)
                    else:
                        pilot.forget(service_id)
                    self._json(200, {"ok": True})
                    return
                if action == "test" and is_post:
                    if pilot.enqueue("Connection check", service_id):
                        self._json(202, {"ok": True})
                    else:
                        self._json(409, {"error": "Save a service address with a supported probe before testing."})
                    return
            self._json(404, {"error": "Action unavailable in the read-only pilot."})
        except (ValueError, UnicodeError) as error:
            message = str(error) if not isinstance(error, (json.JSONDecodeError, UnicodeError)) else "Invalid request encoding."
            self._json(400, {"error": message})
        except OSError:
            self._json(503, {"error": "Windows could not save this setup locally."})


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=18746)
    parser.add_argument("--open", action="store_true", help="Open Watch in the default browser.")
    options = parser.parse_args()
    local_app_data = os.environ.get("LOCALAPPDATA")
    if os.name != "nt" or not local_app_data:
        parser.exit(1, "The Windows pilot requires a local Windows user profile.\n")
    data_dir = Path(local_app_data) / "PlexMediaIntelligencePilot"
    try:
        with Server(("127.0.0.1", options.port), Handler) as server:
            pilot = Pilot(data_dir)
            server.pilot = pilot
            try:
                print(f"Plex Media Intelligence preview  {server.origin}/", flush=True)
                print(f"Private Manage code  {pilot.code}", flush=True)
                print("Leave this window open to run the local scheduler. Press Ctrl+C to stop.", flush=True)
                pilot.start()
                if options.open:
                    webbrowser.open(server.origin + "/")
                server.serve_forever(poll_interval=0.2)
            except KeyboardInterrupt:
                pass
            finally:
                pilot.close()
    except (OSError, RuntimeError) as error:
        parser.exit(1, f"Preview could not start. {error}\n")


if __name__ == "__main__":
    main()
