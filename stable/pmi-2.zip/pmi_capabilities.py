from __future__ import annotations

# M1 capabilities are intentionally positive allowlists rather than a list of blocked writes.
M1_CAPABILITIES: tuple[str, ...] = (
    "control_plane_health_read",
    "build_identity_read",
    "evidence_read",
    "integration_health_read",
    "storage_state_read",
)

M1_EXTERNAL_MUTATION_ENABLED = False
