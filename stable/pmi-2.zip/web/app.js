"use strict";

const content = document.getElementById("content");
const dialog = document.getElementById("service-dialog");
const panel = document.getElementById("service-panel");
const lockButton = document.getElementById("lock-button");
const tabs = { services: "Services", storage: "QNAP Storage", quality: "Quality Engine", activity: "Activity", recommendations: "Recommendations", updates: "Updates" };
const qnapStoragePath = "/api/qnap/storage";
const icons = {
  play: '<path d="m9 5 12 7-12 7z" fill="currentColor" stroke="none"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  shield: '<path d="M12 22s7-3.5 7-9V5l-7-3-7 3v8c0 5.5 7 9 7 9Z"/><path d="m9 12 2 2 4-4"/>',
  disk: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 13h18m-14 3h.01m4 0h.01"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  arrow: '<path d="M4 12h15m-6-6 6 6-6 6"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
  cross: '<path d="m6 6 12 12M18 6 6 18"/>',
  refresh: '<path d="M20 7v5h-5M4 17v-5h5m10-3a8 8 0 0 0-13-2m12 10a8 8 0 0 1-13-2"/>',
  lock: '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
};
const signs = { selected: "Selected", rejected: "Rejected", eligible: "Eligible", would_grab: "Would grab", wait: "Wait", keep_existing: "Keep existing" };
let snapshot = null;
let viewSignature = "";
let refreshRequest;
let activeService = null;
let toastTimer;
let filterText = "";
let updatesPolicyDirty = false;
let qnapWritePending = false;

function html(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}

function icon(name) {
  return `<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[name] ?? ""}</svg>`;
}

function webLink(raw) {
  try {
    const url = new URL(raw);
    return ["http:", "https:"].includes(url.protocol) && !url.username && !url.password ? url.href : "";
  } catch {
    return "";
  }
}

function timeLabel(raw) {
  if (!raw) return "";
  const time = new Date(raw);
  return Number.isNaN(time.getTime()) ? "" : new Intl.DateTimeFormat(undefined, { dateStyle: "short", timeStyle: "short" }).format(time);
}

function tag(value) {
  if (value === "fixture") return '<span class="tag fixture">Fixture</span>';
  if (value === "live") return '<span class="tag live">Live</span>';
  return '<span class="tag">No evidence</span>';
}

function badge(label, tone = "") {
  return `<span class="badge ${tone}">${html(label)}</span>`;
}

function stateLabel(value, positive, negative) {
  if (value === true) return badge(positive, "good");
  if (value === false) return badge(negative);
  if (typeof value === "string" && value) return badge(value);
  return badge("Pending");
}

function bulletList(items) {
  return Array.isArray(items) && items.length ? `<ul class="simple-list">${items.map(item => `<li>${html(item)}</li>`).join("")}</ul>` : "";
}

function route() {
  const [view, tab] = location.hash.slice(1).split("/");
  return view === "manage" ? ["manage", Object.hasOwn(tabs, tab) ? tab : "services"] : ["watch", null];
}

function openPlex(url) {
  return url ? `<a class="button primary" href="${html(url)}" target="_blank" rel="noopener noreferrer">${icon("play")} Open Plex</a>` : "";
}

const playbackCoachStates = {
  live: { label: "Live read", tone: "good", empty: "Active sessions are reported. Waiting for video and audio playback details." },
  idle: { label: "Idle", tone: "good", empty: "No active playback in the latest check." },
  stale: { label: "Stale evidence", tone: "amber", empty: "The last playback observation has expired. Waiting for a fresh read." },
  missing: { label: "No evidence", tone: "", empty: "Session details will appear after Plex or Tautulli reports them." },
  unavailable: { label: "Service unavailable", tone: "alert", empty: "Playback data is unavailable. Watch remains ready while PMI retries." },
  historical: { label: "Earlier session", tone: "", empty: "No earlier session is available." },
};

function playbackTrack(label, mode) {
  const reportedMode = ["Direct Play", "Direct Stream", "Transcode"].includes(mode) ? mode : "Not reported";
  const tone = reportedMode === "Direct Play" ? "good" : reportedMode === "Transcode" ? "amber" : "";
  return `<div><dt>${label}</dt><dd>${badge(reportedMode, tone)}</dd></div>`;
}

function playbackSession(session, status) {
  const resolution = session.resolution || "Not reported";
  const transcoding = session.video_mode === "Transcode" || session.audio_mode === "Transcode";
  const reason = transcoding ? `<p class="playback-reason">${html(session.reason || "Reason not reported")}</p>` : "";
  const suggestion = status !== "stale" && session.suggestion
    ? `<p class="playback-suggestion"><strong>Try this</strong> ${html(session.suggestion)}</p>`
    : "";
  return `<article class="playback-session">
    <div class="playback-session-head">
      <h3>${html(session.device || "Device not reported")}</h3>
      <span class="playback-resolution"><span>Resolution</span> ${html(resolution)}</span>
    </div>
    <dl class="playback-tracks">
      ${playbackTrack("Video", session.video_mode)}
      ${playbackTrack("Audio", session.audio_mode)}
    </dl>
    ${reason}
    ${suggestion}
  </article>`;
}

function playbackCoachView(coach) {
  const status = Object.hasOwn(playbackCoachStates, coach?.status) ? coach.status : "missing";
  const presentation = playbackCoachStates[status];
  const source = ["Plex", "Tautulli"].includes(coach?.source) ? coach.source : "";
  const checkedAt = timeLabel(coach?.checked_at);
  const canShowSessions = ["live", "stale", "historical"].includes(status);
  const sessions = canShowSessions && Array.isArray(coach?.sessions)
    ? coach.sessions.filter(session => session && typeof session === "object")
    : [];
  const metadata = [source, checkedAt].filter(Boolean);
  const context = status === "historical" ? "Verified during one earlier session."
    : status === "stale" && sessions.length ? "Last reported playback details." : "";
  return `<section class="section" aria-labelledby="playback-coach-title">
    <div class="playback-coach">
      <div class="playback-coach-head">
        <h2 id="playback-coach-title">Playback Coach</h2>
        <div class="playback-coach-status">
          ${metadata.length ? `<span>${html(metadata.join(" · "))}</span>` : ""}
          ${badge(presentation.label, presentation.tone)}
        </div>
      </div>
      ${context ? `<p class="playback-context">${context}</p>` : ""}
      ${sessions.length
        ? `<div class="playback-sessions">${sessions.map(session => playbackSession(session, status)).join("")}</div>`
        : `<p class="playback-empty">${presentation.empty}</p>`}
    </div>
  </section>`;
}

function watchView() {
  const watch = snapshot.watch ?? {};
  const plexUrl = webLink(watch.plex_url);
  const playing = Array.isArray(watch.playing) ? watch.playing : [];
  const activity = watch.plex_activity;
  const activeLabel = activity && Number.isInteger(activity.active_sessions)
    ? `${activity.active_sessions} ${activity.stale ? "at last Plex check" : `active Plex ${activity.active_sessions === 1 ? "session" : "sessions"}`}`
    : "";
  return `<section class="hero" aria-labelledby="hero-title">
    <div class="frame hero-body">
      <div class="hero-copy">
        <div class="hero-kicker">${tag(watch.evidence)} <span class="eyebrow">Plex Watch</span></div>
        <h1 id="hero-title">Horizon<br>Archive</h1>
        <div class="hero-meta"><span>Preview showcase</span><span>Windows + QNAP</span></div>
        <p>${plexUrl ? "Open your Plex server to watch." : "Connect Plex in Manage to open your server from Watch."}</p>
        <div class="hero-actions">
          ${openPlex(plexUrl)}
          <a class="button secondary" href="#manage">${icon("grid")} ${snapshot.manage_unlocked ? "Manage services" : "Open Manage"}</a>
        </div>
      </div>
      <aside class="hero-plaque" aria-label="Playback status"><strong>${html(activeLabel || watch.status || "Plex status pending")}</strong><span>${icon("shield")} ${activity ? (activity.stale ? "Saved Plex observation" : "Live Plex observation") : "Plex serves playback independently."}</span></aside>
    </div>
  </section>
  <div class="frame watch-content">
    ${playbackCoachView(watch.playback_coach)}
    ${playing.length ? `<section class="section" aria-labelledby="playing-title"><div class="section-head"><div><h2 id="playing-title">Playing now</h2></div>${tag(watch.evidence)}</div>
    <div class="watch-grid">${playing.map(item => `<article class="watch-card">${tag(watch.evidence)}<h3>${html(item.title ?? item)}</h3><p>${html(item.device ?? item.mode ?? "Plex")}</p></article>`).join("")}</div></section>` : ""}
    <section class="section" aria-labelledby="rec-title">
      <div class="section-head"><div><h2 id="rec-title">Recommendations</h2><p>Suggestions for your next watch. Automatic grabs use their own list and rules.</p></div>${tag(snapshot.recommendations?.evidence)}</div>
      ${recommendationCards(snapshot.recommendations)}
    </section>
  </div>`;
}

function recommendationCards(recommendations) {
  const items = recommendations?.items ?? [];
  return items.length ? `<div class="watch-grid">${items.map(item => `<article class="watch-card">
    <span class="tag${recommendations.evidence === "fixture" ? " fixture" : ""}">${html([item.kind, item.year].filter(Boolean).join(" · ") || "Suggestion")}</span><h3>${html(item.title)}</h3><p>${html(item.reason)}</p>
  </article>`).join("")}</div>` : '<p class="empty-state">No recommendations available.</p>';
}

function unlockView() {
  return `<div class="frame unlock-wrap"><form id="unlock-form" class="unlock-card">
    <span class="eyebrow">${icon("lock")} Private workspace</span>
    <h1>Unlock Manage</h1>
    <p>${html(snapshot.manage_prompt ?? "Enter the Manage code from Windows Setup.")}</p>
    <label class="field" for="access-code">Access code<input id="access-code" name="code" type="password" autocomplete="off" required></label>
    <button class="button primary" type="submit">Unlock ${icon("arrow")}</button>
    <p class="error-message" id="unlock-error" role="alert"></p>
  </form></div>`;
}

function stat(symbol, title, primary, detail, chip = "") {
  return `<article class="stat"><h2>${icon(symbol)} ${html(title)}</h2><strong>${html(primary)}</strong>${chip}<p>${html(detail)}</p></article>`;
}

function currentQnapReading() {
  const storage = snapshot.storage ?? {};
  const { available_bytes, reported_free_bytes } = storage;
  if (snapshot.qnap_storage?.configured !== true || storage.evidence !== "live" || storage.stale !== false || !timeLabel(storage.checked_at)) return null;
  if (!["met", "below"].includes(storage.reserve_status)) return null;
  if (![available_bytes, reported_free_bytes].every(bytes => Number.isSafeInteger(bytes) && bytes >= 0)) return null;
  return { ...storage, freeBytes: Math.min(available_bytes, reported_free_bytes) };
}

function terabytes(bytes) {
  return `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 6 }).format(Math.floor(bytes / 1e6) / 1e6)} TB`;
}

function sizeLabel(bytes) {
  return `${terabytes(bytes)} (${new Intl.NumberFormat().format(bytes)} bytes)`;
}

function reserveLabel(reading, reserve) {
  if (!reading) return `${reserve} TB reserve unverified`;
  return reading.reserve_status === "met" ? `${reserve} TB reserve met` : `Below the ${reserve} TB reserve`;
}

function qnapReadingDetail(storage) {
  if (storage.stale) return "The last measurement expired. Waiting for a current service measurement.";
  if (storage.evidence === "fixture") return "Waiting for a measurement from the Windows service.";
  return storage.detail ?? "Waiting for a successful service measurement.";
}

function summaryGrid() {
  const services = snapshot.services ?? [];
  const liveVerified = services.filter(service => (service.evidence ?? service.source) === "live" && service.verified === true).length;
  const scheduler = snapshot.scheduler ?? {};
  const storage = snapshot.storage ?? {};
  const reading = currentQnapReading();
  const prism = snapshot.prism ?? {};
  return `<div class="summary-grid">
    ${stat("grid", "Service registry", `${services.length} services`, `${liveVerified} verified on a live endpoint`)}
    ${stat("clock", "Shared scheduler", scheduler.active ? "Running 1 job" : "Idle", `${scheduler.queued ?? 0} queued · ${scheduler.worker_limit ?? 1} worker limit`)}
    ${stat("disk", "Media storage", reading ? `${terabytes(reading.freeBytes)} free` : "Awaiting evidence", reserveLabel(reading, storage.reserve_tb ?? 2), tag(reading ? "live" : storage.evidence === "fixture" ? "fixture" : null))}
    ${stat("shield", "PRISM", prism.status ?? "Protected", prism.detail ?? "Separate from the preview")}
  </div>`;
}

function manageView(tab) {
  const renderTab = { services: servicesView, storage: qnapStorageView, quality: qualityView, activity: activityView, recommendations: recommendationsView, updates: updatesView }[tab];
  return `<div class="frame manage">
    <div class="manage-header"><div><div class="eyebrow">Private workspace</div><h1>Manage</h1><p>Service setup and simulated media decisions for the local read-only pilot.</p></div>
    <button type="button" class="button secondary" data-action="refresh">${icon("refresh")} Refresh saved status</button></div>
    <nav class="manage-tabs" aria-label="Manage navigation">${Object.entries(tabs).map(([key, label]) => `<a href="#manage/${key}" ${key === tab ? 'aria-current="page"' : ""}>${label}</a>`).join("")}</nav>
    ${summaryGrid()}
    ${renderTab()}
  </div>`;
}

function updatesStatusContent(updates) {
  const versions = [
    ["Running version", updates.current_version ?? "Unknown"],
    ["Available version", updates.available_version ?? "None reported"],
    ["Previous version", updates.previous_version ?? "None recorded"],
    ["Rollback", updates.rollback ?? "None recorded"],
  ];
  const phase = String(updates.phase ?? "unavailable").replace(/[_-]+/g, " ");
  const rollback = updates.rollback_pending
    ? "<p>Rollback is queued for the quiet window when Plex reports no active sessions.</p>"
    : updates.rollback_available
      ? '<div class="dialog-actions"><button class="button secondary" type="button" data-action="rollback-update">Queue rollback</button></div>'
      : "";
  return `<div class="section-head"><h3>Update status</h3><span class="badge update-phase">${html(phase)}</span></div>
    <dl class="update-versions">${versions.map(([label, value]) => `<div><dt>${html(label)}</dt><dd>${html(value)}</dd></div>`).join("")}</dl>
    ${updates.detail ? `<p>${html(updates.detail)}</p>` : ""}${rollback}`;
}

function updatesView() {
  const updates = snapshot.updates ?? {};
  const policy = updates.policy ?? {};
  const settings = updates.configured
    ? `<form id="updates-form" method="post">
      <label class="update-toggle"><input type="checkbox" name="enabled" ${policy.enabled ? "checked" : ""}>Enable automatic PMI updates</label>
      <label class="update-toggle"><input type="checkbox" name="paused" ${policy.paused ? "checked" : ""}>Pause automatic PMI updates</label>
      <div class="update-times">
        <label class="field">Quiet window start (UTC)<input type="time" name="start" value="${html(policy.start)}" required></label>
        <label class="field">Quiet window end (UTC)<input type="time" name="end" value="${html(policy.end)}" required></label>
      </div>
      <p>PMI applies one verified release at a time when the window is open and Plex reports zero active sessions.</p>
      <div class="dialog-actions"><button class="button primary" type="submit">Save policy</button></div>
      <p class="error-message" role="alert" hidden></p>
    </form>`
    : "<p>Automatic updates are available after the Windows service has an approved release source.</p>";
  const apps = updates.apps ?? [];
  const appRows = apps.length ? `<div class="table-wrap"><table class="update-apps">
      <caption>Connected app update eligibility</caption>
      <thead><tr><th scope="col">App</th><th scope="col">Eligibility</th><th scope="col">Update and recovery</th></tr></thead>
      <tbody>${apps.map(app => `<tr><th scope="row">${html(app.name)}</th>
        <td>${html(String(app.status ?? "Review only").replace(/[_-]+/g, " "))}</td><td>${html(app.detail)}</td></tr>`).join("")}</tbody>
    </table></div>` : "<p>No connected-app updater is enrolled.</p>";
  return `<section class="manage-section" aria-labelledby="updates-heading">
    <div class="section-head"><h2 id="updates-heading">Updates</h2></div>
    <div class="track-grid">
      <article class="panel" id="updates-status" aria-live="polite">${updatesStatusContent(updates)}</article>
      <article class="panel"><h3>Automatic PMI updates</h3>${settings}</article>
    </div>
    <article class="panel update-connected"><h3>Connected apps</h3>
      <p>${html(updates.standing_policy ?? "Standing-policy updates require a verified installation, a supported update method, and a tested recovery path.")}</p>
      ${appRows}
    </article>
  </section>`;
}

function qnapStorageView() {
  const settings = snapshot.qnap_storage ?? {};
  const share = settings.share ? `<code>${html(settings.share)}</code>` : "Multimedia";
  const credentialState = settings.configured ? badge("Credential saved", "good") : badge("Credential needed");
  const setup = settings.supported ? `<div class="section-head"><h3>Service credential</h3>${credentialState}</div>
    <p>Use a dedicated QNAP account with read-only access to Multimedia. The Windows service protects the credential on this PC.</p>
    <form id="qnap-storage-form" method="post" autocomplete="off">
      <label class="field">QNAP account<input name="username" placeholder="NASNAME\\account" autocapitalize="none" spellcheck="false" autocomplete="off" required></label>
      <label class="field">Password<input name="password" type="password" autocomplete="new-password" required></label>
      <label class="qnap-attestation"><input type="checkbox" name="read_only_confirmed" required><span>I confirm this account is dedicated to PMI and has read-only access to the Multimedia share.</span></label>
      <div class="dialog-actions">
        <button type="submit" class="button primary" ${qnapWritePending ? "disabled" : ""}>Save and check</button>
        ${settings.configured ? `<button type="button" class="button secondary" data-action="forget-qnap-storage" ${qnapWritePending ? "disabled" : ""}>Forget credential</button>` : ""}
      </div>
    </form>` : "<h3>Service credential</h3><p>Credential setup is available only through the PMI Windows service.</p>";
  return `<section class="manage-section" aria-labelledby="qnap-storage-title">
    <div class="section-head"><div><h2 id="qnap-storage-title">QNAP Storage</h2><p>Media share ${share}</p></div></div>
    <div class="track-grid"><article class="panel">${setup}</article>
      <article class="panel" id="qnap-storage-reading">${qnapMeasurement()}</article></div>
  </section>`;
}

function qnapMeasurement() {
  const storage = snapshot.storage ?? {};
  const reading = currentQnapReading();
  const reserve = storage.reserve_tb ?? 2;
  const measurement = reading ? `<dl class="qnap-measurement">
      <dt>Available to the QNAP account</dt><dd>${html(sizeLabel(reading.available_bytes))}</dd>
      <dt>Free space reported by the server</dt><dd>${html(sizeLabel(reading.reported_free_bytes))}</dd>
      <dt>Free space used for the reserve check</dt><dd>${html(sizeLabel(reading.freeBytes))}</dd>
    </dl><p>Measured by the Windows service on ${html(timeLabel(reading.checked_at))}.</p>`
    : `<p>${html(qnapReadingDetail(storage))}</p>`;
  return `<div class="section-head"><h3>Media volume reserve</h3>${tag(reading ? "live" : storage.evidence === "fixture" ? "fixture" : null)}</div>
    ${badge(reserveLabel(reading, reserve), reading ? (reading.reserve_status === "met" ? "good" : "alert") : "")}${measurement}`;
}

function servicesView() {
  const services = snapshot.services ?? [];
  const rows = services.map(service => {
    const evidence = service.evidence ?? service.source;
    const detail = service.detail ?? "No endpoint checked.";
    return `<tr data-service-line data-search="${html(`${service.name} ${service.description ?? ""} ${service.ecosystem ?? ""}`.toLowerCase())}">
      <td><div class="service-name"><span class="service-mark" aria-hidden="true">${html(service.name.slice(0, 2))}</span><span><strong>${html(service.name)}</strong><small>${html(service.ecosystem ?? "")}</small></span></div></td>
      <td class="evidence-cell">${tag(evidence)}</td>
      <td class="status-cell">${stateLabel(service.detected, "Detected", "Unknown")}</td>
      <td class="status-cell">${stateLabel(service.connected, "Connected", "Offline")}</td>
      <td class="status-cell">${stateLabel(service.verified, "Verified", "Unverified")}</td>
      <td class="detail-cell">${html(detail)}${service.checked_at ? `<span class="tiny">${html(timeLabel(service.checked_at))}</span>` : ""}</td>
      <td class="service-action"><button class="icon-button" type="button" data-service="${html(service.id)}" aria-label="Set up ${html(service.name)}" title="Set up ${html(service.name)}">${icon("arrow")}</button></td>
    </tr>`;
  }).join("");
  return `<section class="manage-section" aria-labelledby="services-title"><div class="section-head"><div><h2 id="services-title">Services</h2><p>Detection, connection and verification are recorded separately. Open a service to configure the preview connection.</p></div>
    <label class="service-filter">${icon("search")} <input type="search" id="service-filter" value="${html(filterText)}" aria-label="Filter services" placeholder="Find a service"></label></div>
    <div class="table-wrap"><table class="service-table"><caption>Service status and connection setup</caption><thead><tr><th scope="col">Service</th><th scope="col">Evidence</th><th scope="col">Detection</th><th scope="col">Connection</th><th scope="col">Verification</th><th scope="col" class="detail-cell">Latest status</th><th scope="col">Setup</th></tr></thead><tbody>${rows}</tbody></table></div>
    <p id="filter-empty" class="empty-state" role="status" hidden>No matching services.</p>
  </section>`;
}

function formatScore(score) {
  const number = Number(score);
  const tone = number > 0 ? "positive" : number < 0 ? "negative" : "";
  return `<span class="score ${tone}">${html(number > 0 ? `+${score}` : score ?? "—")}</span>`;
}

function profileView(profile) {
  const formats = profile.formats ?? [];
  return `<article class="panel">
    <div class="section-head"><h3>${html(profile.service)} · ${html(profile.name)}</h3>${badge("Proposed", "amber")}</div>
    <p>${html((profile.qualities ?? []).join(" and "))} · Minimum format score ${formatScore(profile.minimum_format_score)}</p>
    ${profile.quality_group?.qualities?.length ? `<p>${html(profile.quality_group.name)} · ${html(profile.quality_group.qualities.join(", "))}</p>` : ""}
    <div class="table-wrap"><table><caption>${html(profile.service)} custom format scores</caption><thead><tr><th scope="col">Custom format</th><th scope="col">Score</th><th scope="col">Rationale</th></tr></thead><tbody>
    ${formats.map(format => `<tr><td>${html(format.name)}</td><td>${formatScore(format.score)}</td><td>${html(format.rationale)}</td></tr>`).join("")}
    </tbody></table></div>${bulletList(profile.notes)}
  </article>`;
}

function candidateView(candidate, index) {
  const source = typeof candidate.source === "object" ? candidate.source?.name : candidate.source;
  const labels = [
    ["Video", [candidate.resolution, candidate.video, candidate.hdr].filter(Boolean).join(" · ")],
    ["Audio", (candidate.audio ?? []).join(", ")],
    ["Subtitles", (candidate.subtitles ?? []).join(", ")],
    ["Bitrate and size", [candidate.bitrate_mbps != null ? `${candidate.bitrate_mbps} Mbps` : "", candidate.size_gb != null ? `${candidate.size_gb} GB` : ""].filter(Boolean).join(" · ")],
    ["Source", source],
  ];
  const tone = candidate.status === "selected" ? "good" : candidate.status === "rejected" ? "alert" : "";
  const breakdown = candidate.score_breakdown;
  const scoreEntries = Array.isArray(breakdown) ? breakdown.map(item => [item.label ?? item.name, item.score ?? item.points]) : Object.entries(breakdown ?? {});
  return `<details class="candidate" data-retain="candidate-${index}" ${candidate.status === "selected" ? "open" : ""}><summary>${badge(signs[candidate.status] ?? candidate.status, tone)} <span class="candidate-title">${html(candidate.name ?? candidate.title)}</span>${candidate.score != null ? formatScore(candidate.score) : ""}</summary>
    <div class="details-inner"><dl>${labels.filter(([, value]) => value).map(([name, value]) => `<dt>${html(name)}</dt><dd>${html(value)}</dd>`).join("")}</dl>
    ${bulletList(candidate.reasons)}
    ${candidate.playback?.length ? `<p>Device playback</p>${bulletList(candidate.playback.map(device => `${device.device}: ${device.mode}. ${device.reason ?? ""}`.trim()))}` : ""}
    ${scoreEntries.length ? `<p>Score components</p><dl>${scoreEntries.map(([name, value]) => `<dt>${html(name)}</dt><dd>${formatScore(value)}</dd>`).join("")}</dl>` : ""}
    </div></details>`;
}

function traceView(trace, traceIndex) {
  const candidates = trace.candidates ?? [];
  const path = trace.path ?? [];
  const outcome = signs[trace.outcome] ?? trace.outcome;
  return `<article class="panel trace">
    <div class="trace-head"><div><span class="eyebrow">${html(trace.kind === "episode" ? "Exact episode" : "Requested movie")}</span><h3>${html(trace.title)}</h3></div>${badge(outcome, trace.outcome === "would_grab" ? "good" : "amber")}</div>
    <p>${html([trace.request_id, trace.exact_identity].filter(Boolean).join(" · "))}</p>
    <p class="trace-summary">${html(trace.summary)}</p>
    <div class="trace-model"><div><h4>Candidate decisions</h4>${candidates.map((candidate, index) => candidateView(candidate, `${traceIndex}-${index}`)).join("")}</div>
    <div><h4>Source to Plex</h4><ol class="path-list">${path.map(step => `<li><strong>${html(step.stage)}<span class="stage-state">${html(step.state)}</span></strong>${html(step.detail)}</li>`).join("")}</ol></div></div>
  </article>`;
}

function qualityView() {
  const quality = snapshot.quality ?? {};
  const policy = quality.policy ?? {};
  return `<section class="manage-section" aria-labelledby="quality-title">
    <div class="section-head"><div><h2 id="quality-title">Quality Engine</h2><p>Simulated requests and proposed profile changes. Live grabs and profile writes are disabled.</p></div>${tag(quality.evidence)}</div>
    <div class="trace-grid">${(quality.traces ?? []).map(traceView).join("")}</div>
    <div class="manage-section profiles"><div class="section-head"><div><h2>Proposed profiles</h2><p>Custom formats for the Windows and QNAP playback pilot.</p></div>${badge("Preview only", "amber")}</div><div class="track-grid">${(quality.profiles ?? []).map(profileView).join("")}</div></div>
    <div class="panel manage-section"><h3>Selection rules</h3>${bulletList(policy.rules)}${policy.devices?.length ? `<p>Device fixtures · ${html(policy.devices.join(" · "))}</p>` : ""}
    <div class="policy-links">${(policy.references ?? []).map(reference => webLink(reference.url) ? `<a href="${html(webLink(reference.url))}" target="_blank" rel="noopener noreferrer">${html(reference.name)}</a>` : "").join("")}</div></div>
  </section>`;
}

function activityView() {
  const scheduler = snapshot.scheduler ?? {};
  const storage = snapshot.storage ?? {};
  const reading = currentQnapReading();
  const prism = snapshot.prism ?? {};
  const recent = scheduler.recent ?? [];
  return `<section class="manage-section" aria-labelledby="activity-title">
    <div class="section-head"><div><h2 id="activity-title">Activity</h2><p>Saved status loads first. The background queue runs one job at a time.</p></div></div>
    <div class="track-grid"><article class="panel"><h3>Scheduler</h3><p>${html(scheduler.active ? `Running ${scheduler.active}` : "Waiting for the next job")} · ${html(scheduler.queued ?? 0)} queued · ${html(scheduler.worker_limit ?? 1)} worker</p>
    ${scheduler.refresh_seconds ? `<p>Service refresh interval · ${html(scheduler.refresh_seconds)} seconds</p>` : ""}</article><article class="panel"><div class="section-head"><h3>Storage and PRISM</h3>${tag(reading ? "live" : storage.evidence === "fixture" ? "fixture" : null)}</div><p>${html(reserveLabel(reading, storage.reserve_tb ?? 2))}</p><p>${html(prism.detail ?? "PRISM state is isolated")}</p></article></div>
    <div class="manage-section"><div class="section-head"><h2>Recent jobs</h2></div>${recent.length ? `<div class="table-wrap"><table><caption>Recent background jobs</caption><thead><tr><th scope="col">Job</th><th scope="col">Finished</th><th scope="col">Outcome</th></tr></thead><tbody>${recent.map(entry => `<tr><td>${html(entry.job)}</td><td>${html(timeLabel(entry.at))}</td><td>${html(entry.outcome)}</td></tr>`).join("")}</tbody></table></div>` : '<p class="empty-state">No background jobs recorded yet.</p>'}</div>
  </section>`;
}

function recommendationsView() {
  const recommendations = snapshot.recommendations ?? {};
  return `<section class="manage-section" aria-labelledby="manage-rec-title">
    <div class="section-head"><div><h2 id="manage-rec-title">Recommendations</h2><p>Suggestions are tracked separately from requested movie and episode decisions.</p></div>${tag(recommendations.evidence)}</div>
    <div class="panel opt-in"><div><h3>Recommendation list opt-in</h3><p>${recommendations.enabled ? "Opt-in saved for this fixture list. Live grabs are disabled." : "Opt in to save this list as a future source of candidates. Live grabs are disabled."}</p></div>
    <button type="button" data-action="opt-in" class="button secondary" aria-pressed="${Boolean(recommendations.enabled)}">${recommendations.enabled ? "Remove opt-in" : "Opt in to this list"}</button></div>
    ${recommendationCards(recommendations)}
  </section>`;
}

function filterServices() {
  const matches = filterText.trim().toLowerCase();
  let total = 0;
  document.querySelectorAll("[data-service-line]").forEach(row => {
    row.hidden = !row.dataset.search.includes(matches);
    if (!row.hidden) total += 1;
  });
  const empty = document.getElementById("filter-empty");
  if (empty) empty.hidden = total > 0;
}

function hasServiceEditorFocus() {
  return document.activeElement?.id === "service-filter" || document.activeElement?.closest("#unlock-form");
}

function hasQnapDraft() {
  const form = document.getElementById("qnap-storage-form");
  return form && (form.contains(document.activeElement) || form.elements.username.value || form.elements.password.value || form.elements.read_only_confirmed.checked);
}

function paint(force = false) {
  if (!snapshot) return;
  const [view, tab] = route();
  const unlocked = snapshot.manage_unlocked;
  for (const name of ["watch", "manage"]) {
    const nav = document.getElementById(`nav-${name}`);
    if (name === view) nav.setAttribute("aria-current", "page");
    else nav.removeAttribute("aria-current");
  }
  lockButton.hidden = !unlocked;
  if (!unlocked && dialog.open) dialog.close();
  const viewState = view === "watch" ? [unlocked, snapshot.watch, snapshot.recommendations] : unlocked ? snapshot : [unlocked];
  const signature = JSON.stringify([view, tab, viewState]);
  if (!force && (signature === viewSignature || hasServiceEditorFocus())) return;
  const updatesForm = document.getElementById("updates-form");
  if (!force && unlocked && tab === "updates" && snapshot.updates?.configured && updatesForm
      && (updatesPolicyDirty || updatesForm.contains(document.activeElement))) {
    const status = document.getElementById("updates-status");
    const reading = updatesStatusContent(snapshot.updates);
    if (status.dataset.updateState !== reading) {
      status.innerHTML = reading;
      status.dataset.updateState = reading;
    }
    return;
  }
  updatesPolicyDirty = false;
  if (!force && unlocked && tab === "storage" && hasQnapDraft()) {
    content.querySelector(".summary-grid").outerHTML = summaryGrid();
    document.getElementById("qnap-storage-reading").innerHTML = qnapMeasurement();
    return;
  }
  const retained = new Map(Array.from(content.querySelectorAll("details[data-retain]"), item => [item.dataset.retain, item.open]));
  content.innerHTML = view === "watch" ? watchView() : unlocked ? manageView(tab) : unlockView();
  for (const item of content.querySelectorAll("details[data-retain]")) {
    if (retained.has(item.dataset.retain)) item.open = retained.get(item.dataset.retain);
  }
  filterServices();
  content.setAttribute("aria-busy", "false");
  viewSignature = signature;
}

function toast(message, isError = false) {
  const element = document.getElementById("toast");
  element.classList.toggle("is-error", isError);
  element.textContent = message;
  element.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { element.hidden = true; }, 5400);
}

async function api(path, options = {}) {
  const headers = { Accept: "application/json" };
  if (options.method && options.method !== "GET") headers["Content-Type"] = "application/json";
  const response = await fetch(path, { credentials: "same-origin", cache: "no-store", signal: AbortSignal.timeout(7000), ...options, headers });
  const type = response.headers.get("content-type") ?? "";
  const body = type.includes("application/json") ? await response.json() : null;
  if (!response.ok) throw new Error(body?.error?.message || body?.error || body?.detail || body?.message || `Request failed (${response.status}).`);
  return body;
}

function post(path, data) {
  return api(path, { method: "POST", body: JSON.stringify(data) });
}

async function writeQnapCredential(form, credential) {
  form.reset();
  if (qnapWritePending || !snapshot?.manage_unlocked || !snapshot.qnap_storage?.supported) return;
  const buttons = form.querySelectorAll("button");
  buttons.forEach(button => { button.disabled = true; });
  qnapWritePending = true;
  try {
    await (credential ? post(qnapStoragePath, credential) : api(qnapStoragePath, { method: "DELETE" }));
    toast(credential ? "QNAP credential saved. A storage check is queued." : "QNAP credential forgotten.");
  } catch {
    toast(credential ? "Could not save the QNAP credential." : "Could not forget the QNAP credential.", true);
  } finally {
    qnapWritePending = false;
    buttons.forEach(button => { button.disabled = false; });
    if (refreshRequest) await refreshRequest.catch(() => {});
    await refresh(true).catch(() => {});
  }
}

function refresh(force = false) {
  if (refreshRequest) return refreshRequest;
  refreshRequest = api("/api/snapshot").then(state => {
    snapshot = state;
    paint(force);
    updateDialogStatus();
    return state;
  }).finally(() => { refreshRequest = null; });
  return refreshRequest;
}

function serviceUrl(service, action) {
  return `/api/services/${encodeURIComponent(service.id)}/${action}`;
}

function activeServiceData() {
  return snapshot?.services?.find(service => service.id === activeService);
}

function updateDialogStatus() {
  const service = activeServiceData();
  if (!service || !dialog.open) return;
  const status = panel.querySelector(".dialog-status");
  const time = timeLabel(service.checked_at);
  status.innerHTML = `${tag(service.evidence ?? service.source)} <span>${html(service.detail ?? service.state ?? "Endpoint not checked.")}${time ? ` · ${html(time)}` : ""}</span>`;
}

function openService(id) {
  activeService = id;
  const service = activeServiceData();
  if (!service) return;
  const capabilities = service.capabilities ?? {};
  panel.innerHTML = `<div class="dialog-head"><div><h2 id="service-dialog-title">${html(service.name)}</h2><p>${html(service.description)}</p></div>
    <button type="button" data-action="close-dialog" class="icon-button" aria-label="Close service setup">${icon("cross")}</button></div>
    <div class="dialog-status" role="status"></div>
    <form id="service-form">
      <label class="field">Service URL<input name="url" type="url" value="${html(service.url ?? "")}" placeholder="http://localhost${service.default_port ? `:${html(service.default_port)}` : ""}" autocomplete="off" required><small>Use the local address and port of the installed service.</small></label>
      <label class="field">${html(service.auth || "Credential")}<input name="secret" type="password" placeholder="${service.has_secret ? "Credential saved" : "Enter credential if required"}" autocomplete="new-password"><small>${service.has_secret ? "Leave blank to retain the saved value." : "Credentials stay with this local preview."}</small></label>
      <div class="dialog-actions"><button type="submit" class="button primary">Save connection</button>
      ${service.probe_supported ? `<button type="button" data-action="test-service" class="button secondary" ${service.url ? "" : "disabled"}>Test saved connection</button>` : ""}
      ${service.url || service.has_secret ? '<button type="button" data-action="remove-service" class="button danger">Remove connection</button>' : ""}</div>
      ${service.probe_supported ? "" : '<p class="muted tiny">No read-only verification probe is available for this service.</p>'}
      <p class="error-message" id="service-error" role="alert"></p>
    </form>
    <details class="capability-wrap" open><summary>Installed service capabilities</summary><dl class="capabilities">
    ${[["Read", "read"], ["Configure", "configure"], ["Update", "update"], ["Restore", "restore"]].map(([label, key]) => `<dt>${label}</dt><dd>${html(capabilities[key] ?? "Unverified")}</dd>`).join("")}
    </dl></details>
    <p class="muted tiny">This pilot enables local connection setup and read-only tests. Service changes are disabled.</p>`;
  if (!dialog.open) dialog.showModal();
  updateDialogStatus();
}

content.addEventListener("input", event => {
  if (event.target.closest("#updates-form")) updatesPolicyDirty = true;
  if (event.target.id === "service-filter") {
    filterText = event.target.value;
    filterServices();
  }
});

async function saveUpdatesPolicy(form) {
  const submit = form.querySelector("button");
  const errorMessage = form.querySelector(".error-message");
  const fields = form.elements;
  submit.disabled = true;
  errorMessage.hidden = true;
  try {
    await post("/api/updates/policy", {
      enabled: fields.enabled.checked,
      paused: fields.paused.checked,
      start: fields.start.value,
      end: fields.end.value,
    });
    updatesPolicyDirty = false;
    if (refreshRequest) await refreshRequest.catch(() => {});
    await refresh(true).catch(() => {});
    toast("Update policy saved.");
  } catch (error) {
    errorMessage.textContent = error.message;
    errorMessage.hidden = false;
  } finally {
    submit.disabled = false;
  }
}

content.addEventListener("submit", async event => {
  if (event.target.id === "updates-form") {
    event.preventDefault();
    await saveUpdatesPolicy(event.target);
    return;
  }
  const form = event.target;
  if (form.id === "qnap-storage-form") {
    event.preventDefault();
    const { username, password, read_only_confirmed } = form.elements;
    await writeQnapCredential(form, { username: username.value.trim(), password: password.value, read_only_confirmed: read_only_confirmed.checked });
    return;
  }
  if (form.id !== "unlock-form") return;
  event.preventDefault();
  const submit = form.querySelector("button");
  const code = new FormData(form).get("code");
  submit.disabled = true;
  try {
    await post("/api/unlock", { code });
    await refresh(true);
  } catch (error) {
    document.getElementById("unlock-error").textContent = error.message;
  } finally {
    submit.disabled = false;
  }
});

content.addEventListener("click", async event => {
  const button = event.target.closest("button");
  if (!button) return;
  if (button.dataset.service) openService(button.dataset.service);
  if (button.dataset.action === "forget-qnap-storage") await writeQnapCredential(button.form, null);
  if (button.dataset.action === "rollback-update" &&
      window.confirm("Queue the previous PMI version for the quiet window when Plex is idle?")) {
    button.disabled = true;
    try {
      await post("/api/updates/rollback", {});
      if (refreshRequest) await refreshRequest.catch(() => {});
      await refresh(true).catch(() => {});
      toast("Rollback queued.");
    } catch (error) {
      toast(error.message, true);
    } finally {
      button.disabled = false;
    }
  }
  if (button.dataset.action === "refresh") {
    button.disabled = true;
    try {
      await refresh(true);
      toast("Saved status refreshed.");
    } catch (error) {
      toast(error.message, true);
    } finally {
      button.disabled = false;
    }
  }
  if (button.dataset.action === "opt-in") {
    const enabled = !snapshot.recommendations?.enabled;
    button.disabled = true;
    try {
      await post("/api/recommendations/opt-in", { enabled });
      await refresh(true);
      toast(enabled ? "Fixture list opt-in saved." : "List opt-in removed.");
    } catch (error) {
      toast(error.message, true);
    } finally {
      button.disabled = false;
    }
  }
});

panel.addEventListener("submit", async event => {
  if (event.target.id !== "service-form") return;
  event.preventDefault();
  const form = event.target;
  const service = activeServiceData();
  if (!service) return;
  const submit = form.querySelector('button[type="submit"]');
  const values = new FormData(form);
  submit.disabled = true;
  try {
    await post(serviceUrl(service, "credentials"), { url: values.get("url"), secret: values.get("secret") });
    form.elements.secret.value = "";
    await refresh(true);
    if (dialog.open && activeService === service.id) openService(service.id);
    toast("Preview connection saved.");
  } catch (error) {
    if (dialog.open && activeService === service.id) panel.querySelector(".error-message").textContent = error.message;
  } finally {
    submit.disabled = false;
  }
});

panel.addEventListener("click", async event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const action = button.dataset.action;
  if (action === "close-dialog") {
    dialog.close();
    return;
  }
  const service = activeServiceData();
  if (!service) return;
  button.disabled = true;
  try {
    if (action === "test-service") {
      await post(serviceUrl(service, "test"), {});
      toast("Read-only connection test queued.");
    }
    if (action === "remove-service") {
      await api(serviceUrl(service, "credentials"), { method: "DELETE" });
      toast("Preview connection removed.");
    }
    await refresh(true);
    if (action === "remove-service" && dialog.open && activeService === service.id) openService(service.id);
  } catch (error) {
    if (dialog.open && activeService === service.id) panel.querySelector(".error-message").textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

dialog.addEventListener("close", () => {
  const id = activeService;
  activeService = null;
  panel.innerHTML = "";
  if (id) content.querySelector(`[data-service="${CSS.escape(id)}"]`)?.focus();
});

lockButton.addEventListener("click", async () => {
  document.getElementById("qnap-storage-form")?.reset();
  lockButton.disabled = true;
  try {
    await post("/api/lock", {});
    await refresh(true);
    toast("Manage locked.");
  } catch (error) {
    toast(error.message, true);
  } finally {
    lockButton.disabled = false;
  }
});

window.addEventListener("hashchange", () => paint(true));
document.querySelector(".skip-link").addEventListener("click", event => {
  event.preventDefault();
  content.focus();
});

refresh().catch(error => {
  content.innerHTML = `<div class="frame manage"><p class="empty-state">${html(error.message)} The preview will retry automatically.</p></div>`;
  content.setAttribute("aria-busy", "false");
});
setInterval(() => {
  if (!document.hidden) refresh().catch(() => {});
}, 4000);
