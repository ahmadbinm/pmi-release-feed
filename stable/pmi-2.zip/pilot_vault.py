"""Windows current-user encryption for credentials supplied through Manage."""

import ctypes
from ctypes import wintypes
import os


class Blob(ctypes.Structure):
    _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]


def _transform(value: bytes, *, protect: bool) -> bytes:
    if os.name != "nt":
        raise OSError("Credential storage requires Windows.")
    source = ctypes.create_string_buffer(value)
    incoming = Blob(len(value), ctypes.cast(source, ctypes.POINTER(ctypes.c_ubyte)))
    outgoing = Blob()
    crypt = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    operation = crypt.CryptProtectData if protect else crypt.CryptUnprotectData
    description_type = wintypes.LPCWSTR if protect else ctypes.POINTER(wintypes.LPWSTR)
    operation.argtypes = [
        ctypes.POINTER(Blob), description_type, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob),
    ]
    operation.restype = wintypes.BOOL
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    try:
        if not operation(ctypes.byref(incoming), None, None, None, None, 1, ctypes.byref(outgoing)):
            raise ctypes.WinError(ctypes.get_last_error())
        return ctypes.string_at(outgoing.data, outgoing.size)
    finally:
        ctypes.memset(source, 0, ctypes.sizeof(source))
        if outgoing.data:
            ctypes.memset(outgoing.data, 0, outgoing.size)
            kernel.LocalFree(outgoing.data)


def encrypt(value: str) -> bytes:
    return _transform(value.encode("utf-8"), protect=True)


def decrypt(value: bytes) -> str:
    return _transform(value, protect=False).decode("utf-8")
