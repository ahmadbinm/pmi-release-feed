"""Evaluate synthetic release data without talking to sources, downloaders, or Plex."""

from dataclasses import asdict, dataclass, replace
from decimal import Decimal
from math import isfinite


RESERVE_GB = 2000
QUALITY_LABELS = {1080: "1080p", 2160: "4K"}
AUTHORIZED_SOURCES = {
    "fixture-studio-usenet": ("Studio screening feed (fixture)", "SABnzbd"),
    "fixture-studio-torrent": ("Studio distribution feed (fixture)", "qBittorrent"),
}


@dataclass(frozen=True)
class Identity:
    provider_id: str
    season: int | None = None
    episode: int | None = None

    def label(self):
        if self.season is None:
            return self.provider_id
        return f"{self.provider_id} · S{self.season:02d}E{self.episode:02d}"


@dataclass(frozen=True)
class Audio:
    language: str
    codec: str
    channels: int

    def label(self):
        return f"{self.language} · {self.codec} · {self.channels}ch"


@dataclass(frozen=True)
class Subtitle:
    language: str
    codec: str
    full: bool = True

    def label(self):
        coverage = "" if self.full else " · forced only"
        return f"{self.language} · {self.codec}{coverage}"


@dataclass(frozen=True)
class Release:
    name: str
    identity: Identity
    source_id: str
    resolution: int
    container: str
    video: str
    hdr: str
    audio: tuple[Audio, ...]
    subtitles: tuple[Subtitle, ...]
    average_mbps: float
    peak_mbps: float
    size_gb: float
    picture_quality: str


@dataclass(frozen=True)
class Device:
    name: str
    max_resolution: int
    max_peak_mbps: float
    containers: tuple[str, ...]
    video: tuple[str, ...]
    hdr: tuple[str, ...]
    audio: tuple[str, ...]
    max_audio_channels: int
    subtitles: tuple[str, ...]


@dataclass(frozen=True)
class Storage:
    qnap_free_gb: float | None
    windows_free_gb: float | None


# These profiles describe sample playback paths, including one 1080p SDR tablet
# and one bandwidth-limited mobile path. No device model or network was probed.
DEVICES = (
    Device("Nvidia Shield", 2160, 100, ("MKV", "MP4"), ("AVC", "HEVC Main 10"),
           ("SDR", "HDR10", "Dolby Vision P5"), ("AAC", "EAC3", "TrueHD"), 8, ("SRT", "PGS")),
    Device("Roku", 2160, 46, ("MKV", "MP4"), ("AVC", "HEVC Main 10"),
           ("SDR", "HDR10"), ("AAC", "EAC3"), 6, ("SRT",)),
    Device("iPad", 1080, 30, ("MP4",), ("AVC", "HEVC Main 10"),
           ("SDR",), ("AAC",), 2, ("SRT",)),
    Device("Mobile", 1080, 25, ("MP4",), ("AVC", "HEVC Main 10"),
           ("SDR",), ("AAC",), 2, ("SRT",)),
)
PLAYBACK_POINTS = {
    "Direct Play": 25, "Direct Stream": 15, "Audio transcode": 9, "Video transcode": 0,
}
SOURCE_VIDEO_MODES = {"Direct Play", "Direct Stream", "Audio transcode"}
PICTURE_POINTS = {"verified native master": 20, "verified native encode": 12}
REFERENCES = [
    {"name": "TRaSH Guides · Radarr quality profiles",
     "url": "https://trash-guides.info/Radarr/radarr-setup-quality-profiles/"},
    {"name": "TRaSH Guides · Sonarr quality profiles",
     "url": "https://trash-guides.info/Sonarr/sonarr-setup-quality-profiles/"},
    {"name": "TRaSH Guides · Quality grouping",
     "url": "https://trash-guides.info/Sonarr/Tips/Merge-quality/"},
    {"name": "Plex · Direct Play and Direct Stream",
     "url": "https://support.plex.tv/articles/200250387-streaming-media-direct-play-and-direct-stream/"},
]


def playback(device, release, language, subtitle_language):
    video_limits = []
    if release.resolution > device.max_resolution:
        video_limits.append("resolution exceeds the device path")
    if release.video not in device.video:
        video_limits.append(f"{release.video} requires conversion")
    if release.hdr not in device.hdr:
        video_limits.append(f"{release.hdr} cannot play in this fixture path")
    if release.peak_mbps > device.max_peak_mbps:
        video_limits.append(f"{release.peak_mbps:g} Mbps peak exceeds {device.max_peak_mbps:g} Mbps")
    tracks = [track for track in release.subtitles if track.language == subtitle_language and track.full]
    if not tracks:
        return "Unavailable", f"A full {subtitle_language} subtitle track is missing"
    if not any(track.codec in device.subtitles for track in tracks):
        video_limits.append(f"{subtitle_language} subtitles require burn-in")
    if video_limits:
        return "Video transcode", ", ".join(video_limits)
    audio_tracks = [track for track in release.audio if track.language == language]
    if not audio_tracks:
        return "Unavailable", f"{language} audio is missing"
    if not any(track.codec in device.audio and track.channels <= device.max_audio_channels
               for track in audio_tracks):
        return "Audio transcode", f"{language} audio needs conversion"
    if release.container not in device.containers:
        return "Direct Stream", f"Repackage the {release.container} container with video and audio intact"
    return "Direct Play", "Compatible video, HDR, peak bitrate, audio, subtitles and container"


def device_results(release, original_language, has_english, has_arabic):
    results = []
    for device in DEVICES:
        mode, reason = playback(device, release, original_language, "English")
        result = {"device": device.name, "mode": mode, "reason": reason}
        if has_english and original_language != "English":
            dub_mode, dub_reason = playback(device, release, "English", "English")
            result["english_audio"] = {"mode": dub_mode, "reason": dub_reason}
        if has_arabic:
            arabic_mode, arabic_reason = playback(device, release, original_language, "Arabic")
            result["arabic_subtitles"] = {"mode": arabic_mode, "reason": arabic_reason}
        results.append(result)
    return results


def storage_projection(release, storage):
    # The fixture stages one downloaded copy plus one working copy on Windows.
    # It budgets one finalized media-sized copy on its separate QNAP share.
    size_known = isfinite(release.size_gb) and release.size_gb > 0
    qnap_known = storage.qnap_free_gb is not None and isfinite(storage.qnap_free_gb) and storage.qnap_free_gb >= 0
    windows_known = storage.windows_free_gb is not None and isfinite(storage.windows_free_gb) and storage.windows_free_gb >= 0
    size = Decimal(str(release.size_gb)) if size_known else None
    windows_needed = float(size * 2) if size_known else None
    qnap_after = float(Decimal(str(storage.qnap_free_gb)) - size) if qnap_known and size_known else None
    return {"reserve_gb": RESERVE_GB, "qnap_free_before_gb": storage.qnap_free_gb if qnap_known else None,
            "qnap_free_after_gb": qnap_after, "windows_free_gb": storage.windows_free_gb if windows_known else None,
            "windows_working_space_gb": windows_needed}


def inspect_release(identity, original_language, release, storage):
    blockers = []
    source = AUTHORIZED_SOURCES.get(release.source_id)
    if source is None:
        blockers.append("Source is outside the explicit fixture authorization list")
    if release.identity != identity:
        blockers.append(f"Exact identity differs: {release.identity.label()}")
    if release.resolution not in QUALITY_LABELS:
        blockers.append("Only 1080p and 4K are eligible")
    if release.picture_quality not in PICTURE_POINTS:
        blockers.append("Native picture detail is unverified or the encode is upscaled")
    has_english = any(track.language == "English" for track in release.audio)
    has_original = any(track.language == original_language for track in release.audio)
    has_english_subtitles = any(track.language == "English" and track.full for track in release.subtitles)
    if not has_original:
        blockers.append(f"Original {original_language} audio is missing")
    if not has_english_subtitles:
        blockers.append("Full English subtitles are required for readiness")
    has_arabic = any(track.language == "Arabic" and track.full for track in release.subtitles)
    if not (0 < release.average_mbps <= release.peak_mbps and isfinite(release.peak_mbps)
            and 0 < release.size_gb and isfinite(release.size_gb)):
        blockers.append("Bitrate or file size metadata is invalid")
    projection = storage_projection(release, storage)
    qnap_before = projection["qnap_free_before_gb"]
    qnap_after = projection["qnap_free_after_gb"]
    if qnap_before is None:
        blockers.append("QNAP free space is unverified")
    elif qnap_after is not None and qnap_after < RESERVE_GB:
        blockers.append(f"Projected QNAP free space is {qnap_after:,} GB, below the 2 TB reserve")
    windows_needed = projection["windows_working_space_gb"]
    windows_free = projection["windows_free_gb"]
    if windows_free is None:
        blockers.append("Windows staging free space is unverified")
    elif windows_needed is not None and windows_free < windows_needed:
        blockers.append("Windows lacks room for its download and working copy")

    predictions = device_results(release, original_language, has_english, has_arabic)
    plays_source_video = any(item["mode"] in SOURCE_VIDEO_MODES for item in predictions)
    if has_original and has_english_subtitles and not plays_source_video:
        blockers.append("Every modeled path would transcode the original video with English subtitles enabled")

    score_breakdown = []
    if not blockers:
        native_4k = release.resolution == 2160
        native_hdr = release.hdr != "SDR"
        playback_points = 0
        for result in predictions:
            expected_modes = [result["mode"]]
            if "english_audio" in result:
                expected_modes.append(result["english_audio"]["mode"])
            playback_points += min(PLAYBACK_POINTS[mode] for mode in expected_modes)
        score_breakdown = [
            {"label": "Playback across four configured paths", "points": playback_points},
            {"label": "Native picture evidence", "points": PICTURE_POINTS[release.picture_quality]},
            {"label": "Playable native 4K", "points": 14 if native_4k else 0},
            {"label": "Playable HDR", "points": 8 if native_hdr else 0},
            {"label": "Full Arabic subtitles", "points": 6 if has_arabic else 0},
        ]

    allowed_resolution = QUALITY_LABELS.get(release.resolution, f"{release.resolution}p")
    return {
        "name": release.name, "exact_identity": release.identity.label(),
        "resolution": allowed_resolution, "container": release.container, "video": release.video,
        "hdr": release.hdr, "audio": [track.label() for track in release.audio],
        "subtitles": [track.label() for track in release.subtitles], "has_english_audio": has_english,
        "bitrate_mbps": release.average_mbps, "peak_mbps": release.peak_mbps, "size_gb": release.size_gb,
        "source": source[0] if source else "Unapproved mirror (fixture)",
        "downloader": source[1] if source else None, "picture_quality": release.picture_quality,
        "status": "rejected" if blockers else "eligible", "reasons": blockers,
        "score": None if blockers else sum(line["points"] for line in score_breakdown),
        "score_breakdown": score_breakdown, "playback": predictions, "storage": projection,
    }


def build_path(kind, selected, working_copy):
    service = "Radarr" if kind == "movie" else "Sonarr"
    return [
        {"stage": "Request and source", "state": "simulated",
         "detail": f"Direct request → {service} identity → Prowlarr allowlisted fixture search. The pilot made no indexer request."},
        {"stage": "Windows download and staging", "state": "proposed" if selected else "held",
         "detail": (f"Would hand off to {selected['downloader']} and stage on Windows. "
                    f"Projection reserves {selected['storage']['windows_working_space_gb']:g} GB for download and working copy."
                    if selected else "No downloader handoff or staging while the request is held.")},
        {"stage": "QNAP import and track check", "state": "proposed" if selected else "held",
         "detail": (f"{service} would map Windows staging to a QNAP library share, then recheck identity, "
                    "availability of both volumes, 2 TB reserve, actual video and language tracks. "
                    "Verify a full English subtitle, embedded or as a validated Bazarr sidecar, before readiness. "
                    "No actual path mappings have been asserted."
                    if selected else "No QNAP write or subtitle job. " +
                    ("Keep the existing media in place." if working_copy else "Reevaluate when a qualifying release becomes available."))},
        {"stage": "Plex read-back", "state": "proposed" if selected else "held",
         "detail": ("After import, Plex would discover the item through its normal library process. "
                    "Confirm the Plex item and read observed playback from Tautulli. All playback modes above are predictions."
                    if selected else "Plex continues serving the existing library.")},
    ]


def decide(kind, title, identity, original_language, releases, storage, working_copy=False):
    candidates = [inspect_release(identity, original_language, release, storage) for release in releases]
    eligible = [candidate for candidate in candidates if candidate["status"] == "eligible"]
    if any(candidate["has_english_audio"] for candidate in eligible):
        for candidate in eligible:
            if not candidate["has_english_audio"]:
                candidate["status"] = "rejected"
                candidate["reasons"].append("A qualifying release preserves both original and English audio")
        eligible = [candidate for candidate in eligible if candidate["has_english_audio"]]

    selected = None
    if working_copy:
        outcome = "keep_existing"
        summary = "Keep the existing working copy. Preference changes never trigger replacement."
        for candidate in eligible:
            candidate["status"] = "rejected"
            candidate["reasons"].append("A working copy is already present")
    elif eligible:
        selected = min(eligible, key=lambda item: (-item["score"], item["size_gb"], item["name"]))
        selected["status"] = "selected"
        selected["reasons"].append("Highest eligible playback and picture score, with size as the first tie-break")
        for candidate in eligible:
            if candidate is not selected:
                candidate["reasons"].append("Another eligible copy ranked higher on playback, picture, languages or size")
        outcome = "would_grab"
        summary = f"Would grab {selected['name']} from the authorized fixture feed. No download was started."
    else:
        outcome = "wait"
        summary = "No release satisfied the identity, source, playback, language and storage rules. Review the blockers and reevaluate only when new evidence arrives."

    return {
        "kind": kind, "title": title, "request_id": f"fixture-request-{kind}",
        "exact_identity": identity.label(), "identity": asdict(identity), "outcome": outcome,
        "summary": summary, "selected": selected, "candidates": candidates,
        "path": build_path(kind, selected, working_copy), "origin": "Direct request (fixture)",
        "evidence": "fixture", "working_copy": working_copy,
    }


def custom_format(name, score, pattern, rationale):
    return {
        "name": name, "score": score, "rationale": rationale, "pattern": pattern,
        "definition": {"name": name, "includeCustomFormatWhenRenaming": False,
                       "specifications": [{"name": "Release title signal",
                                           "implementation": "ReleaseTitleSpecification",
                                           "negate": False, "required": True,
                                           "fields": {"value": pattern}}]},
    }


def propose_profiles():
    profiles = []
    for service, media in (("Radarr", "Movies"), ("Sonarr", "Episodes")):
        formats = [
            custom_format("PMI · Compatible 1080p AVC", 34,
                          r"(?i)^(?=.*\b1080p\b)(?=.*\b(?:avc|[hx][. ]?264)\b)(?!.*\b(?:hdr10\+?|dovi|dolby[ ._-]?vision)\b)",
                          "Prefer the broadly compatible 1080p AVC title signal on this fleet."),
            custom_format("PMI · Native UHD HDR10 signal", 22,
                          r"(?i)^(?=.*\b(?:2160p|4k)\b)(?=.*\bhdr10\b)(?!.*\b(?:upscale[ds]?|dovi|dolby[ ._-]?vision)\b)",
                          "Keep HDR10 UHD in contention. Inspect the actual codec, mastering and HDR metadata separately."),
            custom_format("PMI · Dolby Vision without HDR10 signal", -27,
                          r"(?i)^(?=.*\b(?:dv|dovi|dolby[ ._-]?vision)\b)(?!.*\bhdr10\b)",
                          "Reduce priority when the title signals Dolby Vision and gives no HDR10 fallback signal."),
            custom_format("PMI · Declared upscale", -83, r"(?i)\bupscale[ds]?\b",
                          "Put declared upscales below the proposed minimum score. The engine also checks native picture evidence."),
        ]
        if service == "Sonarr":
            formats.append(custom_format("PMI · Declared full season", -79,
                                         r"(?i)\b(?:complete[ ._-]season|season[ ._-]pack)\b",
                                         "Deprioritize explicitly advertised season packs. Exact episode identity is checked separately."))
        qualities = ["1080p", "4K"]
        profiles.append({
            "service": service, "name": f"PMI · {media} · 1080p and 4K", "status": "proposed",
            "qualities": qualities, "formats": formats, "upgrades_allowed": False,
            "minimum_format_score": -30, "quality_group": {
                "name": "PMI · Native picture", "qualities": [
                    "WEBDL-1080p", "WEBRip-1080p", "Bluray-1080p",
                    "WEBDL-2160p", "WEBRip-2160p", "Bluray-2160p",
                ], "unlisted_qualities_allowed": False,
            },
            "notes": [
                "Put the allowed quality labels in one quality group so a 4K label alone does not win.",
                "Disable upgrades and leave existing profiles and assignments intact during this preview.",
                "These title hints have independent scores. The engine checks audio, subtitle coverage, device playback and storage using structured evidence.",
                "Resolve quality and Custom Format IDs on the installed version before a future authorized write.",
            ],
        })
    return profiles


def get_quality_preview():
    french = Audio("French", "AAC", 2)
    english = Audio("English", "AAC", 2)
    french_cinema = Audio("French", "TrueHD", 8)
    en_text = Subtitle("English", "SRT")
    ar_text = Subtitle("Arabic", "SRT")
    storage = Storage(qnap_free_gb=2030, windows_free_gb=130)

    movie_id = Identity("fixture:tmdb:movie-041")
    movie_hd = Release("Glass Harbor · 1080p AVC", movie_id, "fixture-studio-usenet", 1080, "MP4", "AVC",
                       "SDR", (french, english), (en_text, ar_text), 14, 22, 12.6, "verified native master")
    movie_uhd = Release("Glass Harbor · 4K HDR10", movie_id, "fixture-studio-torrent", 2160, "MKV", "HEVC Main 10",
                        "HDR10", (french, english, french_cinema), (en_text, ar_text), 27, 44, 23.5,
                        "verified native master")
    movie_releases = [
        movie_hd, movie_uhd,
        replace(movie_uhd, name="Glass Harbor · 4K high-bitrate disc encode", peak_mbps=92, size_gb=37.5),
        replace(movie_hd, name="Glass Harbor · French audio only", audio=(french,), size_gb=12.1),
        replace(movie_hd, name="Glass Harbor · 720p", resolution=720, average_mbps=7, peak_mbps=12, size_gb=5.7),
    ]

    episode_id = Identity("fixture:tvdb:series-017", 1, 3)
    episode_hd = Release("Signal Atlas · S01E03 · 1080p", episode_id, "fixture-studio-usenet", 1080, "MP4", "AVC",
                         "SDR", (english,), (Subtitle("English", "SRT", False), ar_text), 12, 19, 5.2,
                         "verified native encode")
    episode_releases = [
        episode_hd,
        replace(episode_hd, name="Signal Atlas · S01E04 · 1080p", identity=Identity(episode_id.provider_id, 1, 4),
                subtitles=(en_text, ar_text)),
        replace(episode_hd, name="Signal Atlas · S01E03 · Mirror 1080p", source_id="unapproved-mirror",
                subtitles=(en_text, ar_text)),
        replace(episode_hd, name="Signal Atlas · S01E03 · 4K Dolby Vision", resolution=2160, container="MKV",
                video="HEVC Main 10", hdr="Dolby Vision P5", subtitles=(Subtitle("English", "PGS"), ar_text),
                average_mbps=28, peak_mbps=108, size_gb=11.7),
    ]
    return {
        "evidence": "fixture",
        "policy": {"reserve_tb": RESERVE_GB / 1000, "qualities": ["1080p", "4K"],
                   "storage": {"reserve_tb": RESERVE_GB / 1000, **asdict(storage), "evidence": "fixture"},
                   "devices": [device.name for device in DEVICES],
                   "device_profiles": [asdict(device) for device in DEVICES], "references": REFERENCES,
                   "rules": [
                       "Use exact requested IDs and episode coordinates from authorized sources.",
                       "Require a native 1080p or 4K picture, original audio and full English subtitles.",
                       "Preserve English audio when a qualifying copy carries it and favor full Arabic subtitles.",
                       "Prefer Direct Play across the four fixture paths. Rank eligible releases by playback, picture and Arabic subtitles, then by smaller size.",
                       "Keep at least 2 TB free on QNAP and verify Windows staging space separately.",
                       "Keep any existing working copy. Recommendations enter this path only after explicit list opt-in.",
                   ]},
        "traces": [decide("movie", "Glass Harbor", movie_id, "French", movie_releases, storage),
                   decide("episode", "Signal Atlas · S01E03", episode_id, "English", episode_releases, storage)],
        "profiles": propose_profiles(),
    }
