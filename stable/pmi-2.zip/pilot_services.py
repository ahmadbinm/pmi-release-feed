"""Pilot service catalog and bounded, read-only connection tests."""

from datetime import datetime, timezone
from copy import deepcopy
import http.client
import ipaddress
import json
import re
import ssl
import time
from itertools import islice
from urllib.parse import urlencode, urlsplit
from xml.etree import ElementTree


def _service(name, group, port, description, auth, read, configure, update, restore, docs,
             *, probe=False, required=False):
    return {
        "name": name,
        "ecosystem": group,
        "default_port": port,
        "description": description,
        "auth": auth,
        "probe_supported": probe,
        "credential_required": required,
        "documentation": docs,
        "capabilities": {"read": read, "configure": configure, "update": update,
                         "restore": restore},
    }


_SERVICES = {
    "plex": _service(
        "Plex Media Server", "Playback", 32400, "Library and playback server", "Plex token",
        "Server presence and active session count via the read-only Plex API.",
        "Library and server settings use the existing Plex Web App. Pilot changes are locked.",
        "Native Plex updater or the installed package's update path.",
        "Plex data directory and platform settings from a compatible backup.",
        "https://developer.plex.tv/pms/", probe=True),
    "sabnzbd": _service(
        "SABnzbd", "Download", 8080, "Usenet download client", "SABnzbd API key",
        "Read queue access and an aggregate queue count with an API key.",
        "Categories, paths and limits in the native UI. Pilot changes are locked.",
        "Existing installer or container image, after the queue is idle.",
        "Compatible application configuration backup with queue data handled separately.",
        "https://sabnzbd.org/wiki/configuration/5.1/api", probe=True, required=True),
    "qbittorrent": _service(
        "qBittorrent", "Download", 8080, "Torrent download client", "Web API key on qBittorrent 5.2+ or existing local read access",
        "Application and Web API versions. An existing local WebUI bypass may allow a tokenless check.",
        "Categories, limits and paths in the native WebUI. Pilot changes are locked.",
        "Existing installer or container image, after active work is reconciled.",
        "Application configuration and resume data from a compatible backup.",
        "https://github.com/qbittorrent/qBittorrent/wiki/WebUI-API-(qBittorrent-5.0)", probe=True),
    "bazarr": _service(
        "Bazarr", "Subtitles", 6767, "Subtitle availability and language profiles", "Bazarr API key",
        "Read system status and version.",
        "Subtitle providers and language profiles in Bazarr. Pilot changes are locked.",
        "Native installer or container update with a configuration backup.",
        "Native backup restore for a compatible Bazarr version.",
        "https://wiki.bazarr.media/", probe=True, required=True),
    "crosswatch": _service(
        "CrossWatch", "Playback", 8787, "Watch state synchronization", "Native sign-in",
        "Run history and snapshot summaries in the native UI. Pilot probe pending installed-version review.",
        "Sync pairs and directions in the native UI. Pilot changes are locked.",
        "Replace the container image with the active data volume preserved.",
        "Review native snapshots and their scope before any watch-state restore.",
        "https://wiki.crosswatch.app/"),
    "kometa": _service(
        "Kometa", "Maintenance", None, "Plex collections and metadata jobs", "Native job and logs",
        "Run logs and installed version from the existing job. Pilot probe unavailable.",
        "Collections and overlays use Kometa's own settings. Pilot changes are locked.",
        "Update the existing installation or image with the configuration retained.",
        "Restore the Kometa configuration bundle. Plex metadata recovery is separate.",
        "https://kometa.wiki/en/latest/kometa/install/files/"),
    "maintainerr": _service(
        "Maintainerr", "Maintenance", 6246, "Library maintenance rules", "No API key for the documented health endpoint",
        "Read local database health on versions with the readiness endpoint.",
        "Rules and collection actions in the native UI. Pilot changes are locked.",
        "Existing container image after a compatible data snapshot.",
        "Restore compatible application data and exported rules after checking dry-run scope.",
        "https://docs.maintainerr.info/api/app-and-health/", probe=True),
    "notifiarr": _service(
        "Notifiarr", "Notifications", 5454, "Notifications and local integration health", "Native sign-in and client credentials",
        "Read version and integration health in the client UI. Pilot probe pending installed-version review.",
        "Notification routing and endpoints in the native client. Pilot changes are locked.",
        "Existing client package or container image.",
        "Restore compatible client configuration. Cloud account state is separate.",
        "https://notifiarr.wiki/pages/client/system/"),
    "plex-auto-languages": _service(
        "Plex Auto Languages", "Playback", None, "Per-series audio and subtitle choices", "Native job and logs",
        "Run logs and image version from the existing job. Pilot probe unavailable.",
        "Language behavior uses the service's own settings. Pilot changes are locked.",
        "Update the existing image with the configuration retained.",
        "Restore service configuration. A Plex track selection restore would require separate review.",
        "https://github.com/RemiRigal/Plex-Auto-Languages"),
    "profilarr": _service(
        "Profilarr", "Quality", 6868, "Radarr and Sonarr profile synchronization", "Native sign-in",
        "Review linked profiles and sync history in Profilarr. Pilot probe pending installed-version review.",
        "Profile sync affects Radarr and Sonarr. Pilot changes are locked.",
        "Confirm major version compatibility before updating the existing image.",
        "Use a compatible application data snapshot. Existing Arr profiles have separate backups.",
        "https://github.com/Dictionarry-Hub/Profilarr"),
    "prowlarr": _service(
        "Prowlarr", "Release", 9696, "Indexer management", "Prowlarr API key",
        "Read application identity and version. No indexer requests are sent by this check.",
        "Indexer and application settings in Prowlarr. Pilot changes are locked.",
        "Native updater or pinned container image, depending on packaging.",
        "Native system backup restore on a compatible installation.",
        "https://prowlarr.com/docs/api/", probe=True, required=True),
    "radarr": _service(
        "Radarr", "Quality", 7878, "Movie release and import management", "Radarr API key",
        "Read application identity and version.",
        "Movie quality profiles and Custom Formats are previewed here. Pilot writes are locked.",
        "Native updater or pinned container image, depending on packaging.",
        "Native system backup restore on a compatible installation.",
        "https://radarr.video/docs/api/", probe=True, required=True),
    "seerr": _service(
        "Seerr", "Requests", 5055, "Movie and exact-episode request intake", "Seerr API key",
        "Read aggregate request counts.",
        "Request routing and permissions in the native UI. Pilot changes are locked.",
        "Existing package or pinned container image after a database backup.",
        "Restore compatible settings and SQLite or PostgreSQL data together.",
        "https://docs.seerr.dev/api/seerr-api/", probe=True, required=True),
    "sonarr": _service(
        "Sonarr", "Quality", 8989, "Series and episode release management", "Sonarr API key",
        "Read application identity and version on a supported API version.",
        "Series quality profiles and Custom Formats are previewed here. Pilot writes are locked.",
        "Native updater or pinned container image, depending on packaging.",
        "Native system backup restore on a compatible installation.",
        "https://sonarr.tv/docs/api/", probe=True, required=True),
    "tautulli": _service(
        "Tautulli", "Playback", 8181, "Playback evidence and history", "Tautulli API key",
        "Read aggregate playback activity. Viewer, media and session identifiers are discarded.",
        "Reporting and notifications in the native UI. Pilot changes are locked.",
        "Existing updater or image after config and database backup.",
        "Compatible native config and database recovery.",
        "https://docs.tautulli.com/extending-tautulli/api-reference", probe=True, required=True),
}


def service_catalog():
    return [{"id": service_id, **deepcopy(service)} for service_id, service in _SERVICES.items()]


def _status(state, detail, *, source="live", detected=False, connected=False,
            verified=False, checked_at=None, version=None, **counts):
    return {"state": state, "detail": detail, "source": source, "detected": detected,
            "connected": connected, "verified": verified, "checked_at": checked_at,
            "version": version, **counts}


def fixture_statuses():
    rows = {}
    for service_id, service in _SERVICES.items():
        if not service["probe_supported"]:
            rows[service_id] = _status("manual", "Fixture only. Registered for manual review.", source="fixture")
        else:
            rows[service_id] = _status("verified", "Fixture only. Sample read response verified.", source="fixture",
                                       detected=True, connected=True, verified=True)
    rows["plex"]["active_sessions"] = 1
    rows["notifiarr"]["detected"] = True
    rows["notifiarr"]["detail"] = "Fixture only. Simulated installed client with no pilot API check."
    rows["bazarr"] = _status("unavailable", "Fixture only. Simulated endpoint unavailable.", source="fixture")
    return rows


_LOCAL_NETWORKS = tuple(ipaddress.ip_network(network) for network in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "fc00::/7",
))
_PATH_PREFIX = re.compile(r"(?:/[A-Za-z0-9_-]+)*/?")
_VERSION = re.compile(r"v?\d+(?:\.\d+){1,4}(?:[-+][A-Za-z0-9._+-]{1,38})?")
_MAX_RESPONSE = 256 * 1024
_MAX_COACH_SESSIONS = 8
_PLAYBACK_MODES = {
    "directplay": "Direct Play",
    "directstream": "Direct Stream",
    "copy": "Direct Stream",
    "transcode": "Transcode",
}
_COACH_SOURCES = {"plex": "Plex", "tautulli": "Tautulli"}


def validate_base_url(base_url):
    error = "Use a loopback or private LAN IP address with HTTP or HTTPS."
    if not isinstance(base_url, str) or len(base_url) > 512:
        raise ValueError(error)
    base_url = base_url.strip()
    if any(ord(char) <= 32 or ord(char) >= 127 for char in base_url) or any(
        char in base_url for char in "\\?#%"
    ):
        raise ValueError(error)
    try:
        parsed = urlsplit(base_url)
        port = parsed.port
        host = parsed.hostname
        address = ipaddress.ip_address("127.0.0.1" if host == "localhost" else host)
        if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped is not None:
            address = address.ipv4_mapped
    except (ValueError, TypeError):
        raise ValueError(error) from None
    if (parsed.scheme not in {"http", "https"} or parsed.username is not None or
            parsed.password is not None or port == 0 or not _PATH_PREFIX.fullmatch(parsed.path) or
            (not address.is_loopback and not any(address in network for network in _LOCAL_NETWORKS))):
        raise ValueError(error)
    normalized_host = f"[{address}]" if address.version == 6 else str(address)
    authority = f"{normalized_host}:{port}" if port is not None else normalized_host
    return f"{parsed.scheme}://{authority}{parsed.path.rstrip('/')}"


def validate_connection(base_url, credential=""):
    base_url = validate_base_url(base_url)
    if (not isinstance(credential, str) or len(credential) > 2048 or
            any(ord(char) < 33 or ord(char) > 126 for char in credential)):
        raise ValueError("Enter a valid API key or token.")
    target = urlsplit(base_url)
    if credential and target.scheme == "http" and not ipaddress.ip_address(target.hostname).is_loopback:
        raise ValueError("Connections with credentials require HTTPS on the LAN or HTTP on this PC's loopback address.")
    return base_url


def _read(base_url, path, headers, timeout, query=None):
    target = urlsplit(base_url)
    connection_type = http.client.HTTPSConnection if target.scheme == "https" else http.client.HTTPConnection
    connection = connection_type(target.hostname, target.port, timeout=timeout)
    request_path = target.path + path
    if query:
        request_path += "?" + urlencode(query)
    deadline = time.monotonic() + timeout
    try:
        connection.connect()
        network_socket = connection.sock
        connection.request("GET", request_path, headers={"Accept": "application/json", **headers})
        with connection.getresponse() as response:
            if response.status != 200:
                return response.status, b""
            if response.length is not None and response.length > _MAX_RESPONSE:
                return response.status, b""
            body = bytearray()
            while len(body) <= _MAX_RESPONSE:
                if response.isclosed() or response.length == 0:
                    return response.status, bytes(body)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError()
                network_socket.settimeout(remaining)
                chunk = response.read1(min(8192, _MAX_RESPONSE + 1 - len(body)))
                if not chunk:
                    return response.status, bytes(body)
                body.extend(chunk)
            return response.status, b""
    finally:
        connection.close()


def _dict(value):
    return value if isinstance(value, dict) else {}


def _json(body):
    try:
        return _dict(json.loads(body))
    except (ValueError, RecursionError):
        return {}


def _version(value):
    if isinstance(value, str) and _VERSION.fullmatch(value):
        return value
    return None


def _count(value):
    if type(value) is int and 0 <= value < 10**9:
        return value
    if isinstance(value, str) and re.fullmatch(r"[0-9]{1,9}", value):
        return int(value)
    return None


def _plex_container(body):
    container = _dict(_json(body).get("MediaContainer"))
    if container or not body.lstrip().startswith(b"<") or b"<!" in body or b"\x00" in body:
        return container
    try:
        root = ElementTree.fromstring(body)
    except (ElementTree.ParseError, ValueError):
        return {}
    if root.tag != "MediaContainer":
        return {}
    return {
        **root.attrib,
        "Metadata": [_xml_session(item) for item in islice(
            (node for node in root if node.tag in {"Video", "Track"}), _MAX_COACH_SESSIONS)],
    }


def _xml_session(node):
    return {
        "Player": _xml_attributes(node.find("Player")),
        "TranscodeSession": _xml_attributes(node.find("TranscodeSession")),
        "Media": [
            {**media.attrib, "Part": [
                {**part.attrib, "Stream": [stream.attrib for stream in part.findall("Stream")]}
                for part in media.findall("Part")]}
            for media in node.findall("Media")
        ],
    }


def _xml_attributes(node):
    return node.attrib if node is not None else {}


def _meaning(value):
    return re.sub(r"[\s_-]+", "", value.casefold()) if isinstance(value, str) else ""


def _mode(*decisions):
    for decision in decisions:
        mode = _PLAYBACK_MODES.get(_meaning(decision))
        if mode:
            return mode
    return "Not reported"


def _selected(rows):
    if not isinstance(rows, list):
        return {}
    options = [row for row in rows if isinstance(row, dict)]
    marked = [row for row in options if row.get("selected") in (True, 1, "1", "true")]
    if len(marked) == 1:
        return marked[0]
    if len(options) == 1 and "selected" not in options[0]:
        return options[0]
    return {}


def _stream(part, kind):
    streams = part.get("Stream")
    if not isinstance(streams, list):
        return {}
    return _selected([row for row in streams if _count(_dict(row).get("streamType")) == kind])


def _device(*fields):
    # Avoid exposing a custom client name, user name, IP, or device identifier on Watch.
    clues = " ".join(value[:120].casefold() for value in fields if isinstance(value, str))
    for match, label in (
        ("iphone", "iPhone"), ("ipad", "iPad"), ("shield", "Nvidia Shield"),
        ("roku", "Roku"), ("apple tv", "Apple TV"), ("tvos", "Apple TV"),
        ("android tv", "Android TV"), ("plex web", "Plex Web"), ("ios", "Plex for iOS"),
        ("android", "Plex for Android"),
    ):
        if re.search(r"\b" + match, clues):
            return label
    return "Device not reported"


def _resolution(*labels, width=None, height=None):
    for label in labels:
        if not isinstance(label, (str, int)) or isinstance(label, bool):
            continue
        value = str(label).strip().lower()
        if value in {"4k", "uhd", "2160", "2160p"}:
            return "4K"
        if re.fullmatch(r"(240|360|480|540|576|720|900|1080|1440)[pi]?", value):
            return value if value.endswith(("p", "i")) else value + "p"
        if value == "sd":
            return "SD"
    width, height = _count(width), _count(height)
    if not (width and height and max(width, height) <= 16384):
        return None
    if (width, height) == (3840, 2160):
        return "4K"
    if (width, height) in {(1920, 1080), (1280, 720)}:
        return f"{height}p"
    return f"{width}×{height}"


def _coach_session(device, resolution, video, audio, subtitle_decision, subtitle_language):
    if device == "Device not reported" and not resolution and video == audio == "Not reported":
        return None
    burned = video == "Transcode" and _meaning(subtitle_decision) in {"burn", "burned", "burnin"}
    reason = "Reason not reported" if "Transcode" in (video, audio) else None
    client = "in Plex Web" if device == "Plex Web" else (
        "on this device" if device == "Device not reported" else f"on your {device}"
    )
    if burned:
        language = "English subtitles" if _meaning(subtitle_language) in {"en", "eng", "english"} else "Subtitles"
        reason = f"{language} are being burned into the video."
        if audio == "Transcode":
            reason += " Audio transcode: Reason not reported."
        suggestion = f"If available, try a full English SRT subtitle track {client}."
    elif video == "Transcode":
        suggestion = f"Try a compatible 1080p version with full English subtitles {client} and check for Direct Play."
    elif audio == "Transcode":
        suggestion = f"If available, try an AAC audio track {client} and keep the required English subtitles."
    elif video == audio == "Direct Play" and resolution in {"4K", "1080p"}:
        suggestion = f"Keep this {resolution} version {client} and select full English subtitles."
    else:
        suggestion = f"Try Original quality with a 4K or 1080p version {client} and keep the required English subtitles."
    return {"device": device, "resolution": resolution, "video_mode": video, "audio_mode": audio,
            "reason": reason, "suggestion": suggestion}


def _plex_playback(item):
    player = _dict(item.get("Player"))
    device = _device(player.get("model"), player.get("device"), player.get("product"), player.get("platform"))
    transcode = _dict(item.get("TranscodeSession"))
    media = _selected(item.get("Media"))
    part = _selected(media.get("Part"))
    video_stream = _stream(part, 1)
    audio_stream = _stream(part, 2)
    subtitle = _stream(part, 3)
    direct = "directplay" if _mode(part.get("decision"), media.get("decision")) == "Direct Play" else None
    video = _mode(transcode.get("videoDecision"), part.get("videoDecision"), media.get("videoDecision"),
                  direct if media.get("videoCodec") or video_stream else None, video_stream.get("decision"))
    audio = _mode(transcode.get("audioDecision"), part.get("audioDecision"), media.get("audioDecision"),
                  direct if media.get("audioCodec") or audio_stream else None, audio_stream.get("decision"))
    if video == "Transcode":
        resolution = _resolution(transcode.get("videoResolution"), width=transcode.get("width"),
                                 height=transcode.get("height"))
    else:
        resolution = _resolution(media.get("videoResolution"), width=media.get("width"), height=media.get("height"))
    return _coach_session(device, resolution, video, audio, transcode.get("subtitleDecision") or subtitle.get("decision"),
                          subtitle.get("languageCode") or subtitle.get("language"))


def _tautulli_playback(item):
    device = _device(item.get("product"), item.get("platform_name"), item.get("platform"))
    # Tautulli's player field can be a user-selected name.
    video = _mode(item.get("stream_video_decision"), item.get("video_decision"))
    audio = _mode(item.get("stream_audio_decision"), item.get("audio_decision"))
    if video == "Transcode":
        resolution = _resolution(width=item.get("transcode_width"), height=item.get("transcode_height"))
        resolution = resolution or _resolution(item.get("stream_video_full_resolution"), item.get("stream_video_resolution"),
                                               width=item.get("stream_video_width"), height=item.get("stream_video_height"))
    else:
        resolution = _resolution(item.get("stream_video_full_resolution"), item.get("stream_video_resolution"),
                                 item.get("video_full_resolution"), item.get("video_resolution"),
                                 width=item.get("stream_video_width") or item.get("video_width"),
                                 height=item.get("stream_video_height") or item.get("video_height"))
    return _coach_session(device, resolution, video, audio, item.get("stream_subtitle_decision"),
                          item.get("stream_subtitle_language_code") or item.get("stream_subtitle_language"))


def _coach_rows(items, parse):
    if not isinstance(items, list):
        return []
    return [session for item in items[:_MAX_COACH_SESSIONS] if (session := parse(_dict(item)))]


def remember_playback(service_id, result, previous_json):
    """Keep the latest verified playback read through a failed scheduled probe."""
    if service_id not in _COACH_SOURCES:
        return
    sessions = result.pop("playback_sessions", [])
    count = _count(result.get("active_sessions"))
    if result.get("source") == "live" and result.get("verified") is True and count is not None:
        result["playback_cache"] = {
            "checked_at": result.get("checked_at"),
            "active_sessions": count,
            "sessions": sessions[:min(count, _MAX_COACH_SESSIONS)] if isinstance(sessions, list) else [],
        }
    elif previous_json:
        previous = _json(previous_json)
        if "playback_cache" in previous:
            result["playback_cache"] = previous["playback_cache"]
        elif previous.get("source") == "live" and previous.get("verified") is True:
            result["playback_cache"] = {
                "checked_at": previous.get("checked_at"),
                "active_sessions": previous.get("active_sessions"),
                "sessions": [],
            }


def _cached_read(service_id, status, now, stale_after):
    cache = _dict(status.get("playback_cache"))
    if not cache and status.get("source") == "live" and status.get("verified") is True:
        # Older saved data can verify a count, with no device or track evidence.
        cache = status
    stamp = cache.get("checked_at")
    count = _count(cache.get("active_sessions"))
    if not isinstance(stamp, str) or count is None:
        return None
    try:
        time = datetime.fromisoformat(stamp)
        age = now - time
    except (ValueError, TypeError):
        return None
    if age.total_seconds() < 0:
        return None
    rows = cache.get("sessions")
    sessions = ([row for row in rows[:min(count, _MAX_COACH_SESSIONS)] if isinstance(row, dict)]
                if isinstance(rows, list) else [])
    stale = (status.get("source") != "live" or status.get("verified") is not True or
             stamp != status.get("checked_at") or age >= stale_after)
    return {"source": _COACH_SOURCES[service_id], "checked_at": stamp, "active_sessions": count,
            "sessions": sessions, "time": time, "stale": stale}


def playback_coach(statuses, *, stale_after, now=None):
    """Choose a complete cached read from one provider. Never merge tracks across providers."""
    now = now or datetime.now(timezone.utc)
    evidence = [
        read for service_id, status in statuses.items()
        if (read := _cached_read(service_id, status, now, stale_after))
    ]
    fresh = [read for read in evidence if not read["stale"]]
    ordered = sorted(fresh or evidence, key=lambda read: (read["time"], read["source"] == "Plex"), reverse=True)
    if not ordered:
        unavailable = any(status.get("state") in {"unavailable", "credential_needed"} for status in statuses.values())
        return {"status": "unavailable" if unavailable else "missing", "source": None, "checked_at": None,
                "active_sessions": None, "sessions": []}
    latest = ordered[0]
    if fresh and latest["active_sessions"] and not latest["sessions"]:
        # A current detailed read can fill a provider gap. A newer idle read always wins.
        latest = next((item for item in ordered if item["active_sessions"] == latest["active_sessions"]
                       and item["sessions"]), latest)
    count, rows = latest["active_sessions"], latest["sessions"]
    if not fresh:
        status = "stale"
        rows = [{**row, "suggestion": None} for row in rows]
    elif count == 0:
        status = "idle"
    else:
        status = "live" if rows else "missing"
    return {"status": status, "source": latest["source"], "checked_at": latest["checked_at"],
            "active_sessions": count, "sessions": rows}


def _parse_response(service_id, body, identity):
    data = _json(body)
    if service_id == "plex":
        container = _plex_container(body)
        if identity:
            version = _version(container.get("version"))
            return {"version": version} if version and container.get("machineIdentifier") else None
        count = _count(container.get("size"))
        if count is not None:
            return {"active_sessions": count, "playback_sessions": _coach_rows(container.get("Metadata"), _plex_playback)}
        return None
    if service_id in {"radarr", "sonarr", "prowlarr"}:
        version = _version(data.get("version"))
        return {"version": version} if version and str(data.get("appName")).lower() == service_id else None
    if service_id == "bazarr":
        version = _version(_dict(data.get("data")).get("bazarr_version") or data.get("bazarr_version"))
        return {"version": version} if version else None
    if service_id == "sabnzbd":
        queue = _dict(data.get("queue"))
        count = _count(queue.get("noofslots_total"))
        if _version(queue.get("version")) and count is not None:
            return {"version": queue["version"], "queue_count": count}
    if service_id == "maintainerr" and data.get("status") == "ok" and data.get("database") == "ok":
        if _count(data.get("uptimeSeconds")) is not None and isinstance(data.get("timestamp"), str):
            return {}
    if service_id == "seerr" and all(_count(data.get(key)) is not None for key in ("total", "movie", "tv", "pending")):
        return {"request_count": _count(data["total"])}
    if service_id == "tautulli":
        response = _dict(data.get("response"))
        activity = _dict(response.get("data"))
        count = _count(activity.get("stream_count"))
        direct = _count(activity.get("stream_count_direct_play"))
        if response.get("result") == "success" and count is not None and direct is not None:
            return {"active_sessions": count, "direct_play_sessions": direct,
                    "playback_sessions": _coach_rows(activity.get("sessions"), _tautulli_playback)}
    return None


def _http_status(code, checked_at):
    detail = f"Local endpoint replied with HTTP {code}."
    if code in {401, 403}:
        detail = "Local endpoint denied the read. Check the registered API credential and service access."
    elif 300 <= code < 400:
        detail = "Local endpoint redirected the read. Register the final local service address."
    return _status("unavailable" if code >= 500 else "detected", detail,
                   detected=True, checked_at=checked_at)


_GETS = {
    "plex": ("/status/sessions", "X-Plex-Token"),
    "sabnzbd": ("/api", None),
    "qbittorrent": ("/api/v2/app/version", "Authorization"),
    "bazarr": ("/api/system/status", "X-Api-Key"),
    "maintainerr": ("/api/health/ready", None),
    "prowlarr": ("/api/v1/system/status", "X-Api-Key"),
    "radarr": ("/api/v3/system/status", "X-Api-Key"),
    "seerr": ("/api/v1/request/count", "X-Api-Key"),
    "sonarr": ("/api/v3/system/status", "X-Api-Key"),
    "tautulli": ("/api/v2", None),
}


def probe_service(service_id, base_url, credential="", *, timeout=2.0):
    """Read only considered endpoints. Return no raw response or user data."""
    if service_id not in _SERVICES:
        raise ValueError("Unknown service.")
    service = _SERVICES[service_id]
    if not service["probe_supported"]:
        return _status("manual", "Registered for manual review. Automated verification is unavailable.", source="none")
    if not base_url:
        return _status("unconfigured", "Enter a service URL in Manage to run a connection test.", source="none")
    base_url = validate_connection(base_url, credential)
    if service["credential_required"] and not credential:
        return _status("credential_needed", f"Enter a {service['auth']} to run the read test.", source="none")
    path, header = _GETS[service_id]
    identity = service_id == "plex" and not credential
    if identity:
        path = "/identity"
    headers = {header: credential} if header and credential else {}
    query = None
    if service_id == "qbittorrent" and credential:
        headers["Authorization"] = f"Bearer {credential}"
    if service_id == "sabnzbd":
        query = {"mode": "queue", "output": "json", "limit": 1, "apikey": credential}
    if service_id == "tautulli":
        query = {"cmd": "get_activity", "apikey": credential}
    checked_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    try:
        code, body = _read(base_url, path, headers, timeout, query)
        if code == 404 and service_id == "sonarr":
            code, body = _read(base_url, "/api/v5/system/status", headers, timeout)
        if code != 200:
            return _http_status(code, checked_at)
        if service_id == "qbittorrent":
            version = _version(body.decode("ascii", errors="replace").strip())
            api_code, api_body = _read(base_url, "/api/v2/app/webapiVersion", headers, timeout)
            api_version = _version(api_body.decode("ascii", errors="replace").strip())
            result = {"version": version} if version and api_code == 200 and api_version else None
        else:
            result = _parse_response(service_id, body, identity)
    except ssl.SSLCertVerificationError:
        return _status("unavailable", "The service TLS certificate did not validate.", checked_at=checked_at)
    except (OSError, ValueError, http.client.HTTPException):
        return _status("unavailable", "Local read timed out or the endpoint could not be reached.", checked_at=checked_at)
    if result is None:
        return _status("connected", "The local endpoint answered. The service response could not be verified.",
                       detected=True, connected=True, checked_at=checked_at)
    if credential and result.get("version") == credential:
        result.pop("version")
    if identity:
        return _status("detected", "Plex identity detected. A Plex token is needed to verify a playback read.",
                       detected=True, checked_at=checked_at, **result)
    detail = "Live read verified."
    if service_id == "qbittorrent" and not credential:
        detail = "Live read verified using the WebUI's existing local access."
    return _status("verified", detail, detected=True, connected=True, verified=True,
                   checked_at=checked_at, **result)
