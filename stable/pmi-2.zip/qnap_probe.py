"""Read-only Multimedia capacity evidence from an isolated SMB logon."""

from __future__ import annotations

from contextlib import contextmanager
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import ipaddress
import json
import os
from pathlib import Path
import re
import subprocess
import sys


RESERVE_BYTES = 2_000_000_000_000
_SERVICE_ACCOUNT = r"NT SERVICE\PmiReadOnlyPilot"
_SERVICE_SID = "S-1-5-80-1427841318-2456377751-1586865927-1750748407-2263876467"
_SHARE = re.compile(r"\\\\([0-9.]+)\\([A-Za-z0-9][A-Za-z0-9 _.()-]{0,79})")
_LAN = tuple(ipaddress.IPv4Network(network) for network in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"))
_AUTHORITY = re.compile(r"[A-Za-z0-9][A-Za-z0-9.-]{0,62}")
_MAX_CIPHERTEXT = 16_384
_TIMEOUT_SECONDS = 12

_FAILURES = {
    "identity": "The probe requires the PMI Windows service account.",
    "configuration": "Configure a direct private IPv4 Multimedia share in Manage.",
    "credential": "The service could not open the protected Multimedia credential. Save it again in Manage.",
    "logon": "Windows could not create an isolated SMB logon.",
    "impersonation": "Windows could not activate the isolated SMB logon.",
    "list": "The isolated SMB logon could not list the Multimedia share root.",
    "space": "The isolated SMB logon could not obtain valid free-space counts.",
    "revert": "Windows could not close the isolated SMB logon safely.",
    "timeout": f"The share check exceeded {_TIMEOUT_SECONDS} seconds.",
    "worker": "The service could not obtain a Windows share check result.",
}


def validate_share(share: str) -> str:
    match = _SHARE.fullmatch(share) if isinstance(share, str) else None
    if match is None or match[2].endswith((" ", ".")):
        raise ValueError("Use a direct private IPv4 SMB share root.")
    try:
        address = ipaddress.IPv4Address(match[1])
    except ValueError:
        raise ValueError("Use a direct private IPv4 SMB share root.") from None
    if not any(address in network for network in _LAN):
        raise ValueError("The SMB host is outside the private LAN.")
    return share


def validate_storage_share(share: str) -> str:
    root = validate_share(share)
    if root.rsplit("\\", 1)[1].casefold() != "multimedia":
        raise ValueError("Use the Multimedia share root.")
    return root


def validate_storage_credentials(username: str, password: str) -> tuple[str, str]:
    authority, _, user = username.strip().partition("\\") if isinstance(username, str) else ("", "", "")
    if (
        not _AUTHORITY.fullmatch(authority)
        or not 1 <= len(user) <= 64
        or user != user.strip()
        or not user.isprintable()
        or any(character in user for character in r"\/:@")
        or user.casefold() in {"admin", "administrator", "root", "guest"}
    ):
        raise ValueError("Enter a dedicated read-only NAS account as NASNAME\\username.")
    if not isinstance(password, str) or not 1 <= len(password) <= 256 or not password.isprintable():
        raise ValueError("Enter a password of 1 to 256 printable characters.")
    return f"{authority.upper()}\\{user}", password


class _SidAndAttributes(ctypes.Structure):
    _fields_ = [("sid", ctypes.c_void_p), ("attributes", wintypes.DWORD)]


def is_pmi_service_account() -> bool:
    """Check the process TokenUser, independently of thread impersonation or environment."""
    if os.name != "nt":
        return False
    try:
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        advapi = ctypes.WinDLL("advapi32", use_last_error=True)
        kernel.GetCurrentProcess.argtypes = []
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle.restype = wintypes.BOOL
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree.restype = ctypes.c_void_p
        advapi.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
        advapi.OpenProcessToken.restype = wintypes.BOOL
        advapi.GetTokenInformation.argtypes = [
            wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)
        ]
        advapi.GetTokenInformation.restype = wintypes.BOOL
        advapi.ConvertSidToStringSidW.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.LPWSTR)]
        advapi.ConvertSidToStringSidW.restype = wintypes.BOOL
        token = wintypes.HANDLE()
        if not advapi.OpenProcessToken(kernel.GetCurrentProcess(), 0x0008, ctypes.byref(token)):  # TOKEN_QUERY
            return False
        try:
            size = wintypes.DWORD()
            token_user = 1
            advapi.GetTokenInformation(token, token_user, None, 0, ctypes.byref(size))
            if not ctypes.sizeof(_SidAndAttributes) <= size.value <= 65_536:
                return False
            information = ctypes.create_string_buffer(size.value)
            if not advapi.GetTokenInformation(token, token_user, information, size.value, ctypes.byref(size)):
                return False
            sid_string = wintypes.LPWSTR()
            sid = _SidAndAttributes.from_buffer(information).sid
            if not advapi.ConvertSidToStringSidW(sid, ctypes.byref(sid_string)):
                return False
            try:
                return sid_string.value == _SERVICE_SID
            finally:
                kernel.LocalFree(ctypes.cast(sid_string, ctypes.c_void_p))
        finally:
            kernel.CloseHandle(token)
    except OSError:
        return False


class _ProbeError(Exception):
    def __init__(self, stage: str, code: int | None = None):
        super().__init__(stage)
        self.stage = stage
        self.code = code


@contextmanager
def _outbound_logon(username: str, password: str):
    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi.LogonUserW.argtypes = [
        wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.LPCWSTR,
        wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)
    ]
    advapi.LogonUserW.restype = wintypes.BOOL
    advapi.ImpersonateLoggedOnUser.argtypes = [wintypes.HANDLE]
    advapi.ImpersonateLoggedOnUser.restype = wintypes.BOOL
    advapi.RevertToSelf.argtypes = []
    advapi.RevertToSelf.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL
    authority, user = username.split("\\", 1)
    token = wintypes.HANDLE()
    password_buffer = ctypes.create_unicode_buffer(password)
    logon_new_credentials, provider_winnt50 = 9, 3
    try:
        if not advapi.LogonUserW(
            user, authority, password_buffer, logon_new_credentials, provider_winnt50, ctypes.byref(token)
        ):
            raise _ProbeError("logon", ctypes.get_last_error())
    finally:
        ctypes.memset(password_buffer, 0, ctypes.sizeof(password_buffer))
    try:
        if not advapi.ImpersonateLoggedOnUser(token):
            raise _ProbeError("impersonation", ctypes.get_last_error())
        try:
            yield
        finally:
            if not advapi.RevertToSelf():
                raise _ProbeError("revert", ctypes.get_last_error())
    finally:
        kernel.CloseHandle(token)


def _space(root: str) -> tuple[int, int]:
    query = ctypes.WinDLL("kernel32", use_last_error=True).GetDiskFreeSpaceExW
    query.argtypes = [wintypes.LPCWSTR] + [ctypes.POINTER(ctypes.c_ulonglong)] * 3
    query.restype = wintypes.BOOL
    available, total, free = (ctypes.c_ulonglong() for _ in range(3))
    if not query(root, ctypes.byref(available), ctypes.byref(total), ctypes.byref(free)):
        raise ctypes.WinError(ctypes.get_last_error())
    return available.value, free.value


def _measure(share: str, secret: bytes) -> dict:
    if not is_pmi_service_account():
        return {"error_stage": "identity"}
    result = {"service_identity_verified": True, "read_verified": False}
    try:
        root = validate_storage_share(share) + "\\"
    except ValueError:
        return {**result, "error_stage": "configuration"}
    if not 0 < len(secret) <= _MAX_CIPHERTEXT:
        return {**result, "error_stage": "credential"}
    try:
        from pilot_vault import decrypt

        credential = json.loads(decrypt(secret))
        username, password = validate_storage_credentials(credential["username"], credential["password"])
    except (KeyError, OSError, TypeError, ValueError):
        return {**result, "error_stage": "credential"}
    try:
        with _outbound_logon(username, password):
            try:
                with os.scandir(root) as listing:
                    next(listing, None)
            except OSError as error:
                raise _ProbeError("list", getattr(error, "winerror", None)) from None
            result["read_verified"] = True
            try:
                available, reported = _space(root)
            except OSError as error:
                raise _ProbeError("space", getattr(error, "winerror", None)) from None
    except _ProbeError as error:
        return {**result, "error_stage": error.stage, "error_code": error.code}
    return {**result, "available_bytes": available, "reported_free_bytes": reported}


def _valid_count(count: object) -> bool:
    return type(count) is int and 0 <= count < 2**64


def _summarize(raw: dict) -> dict:
    identity_verified = raw.get("service_identity_verified") is True
    read_verified = identity_verified and raw.get("read_verified") is True
    result = {
        "evidence": "none",
        "service_identity_verified": identity_verified,
        "read_verified": read_verified,
        "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "reserve_status": "unverified",
        "reserve_tb": 2,
        "free_tb": None,
        "account": _SERVICE_ACCOUNT if identity_verified else None,
    }
    available = raw.get("available_bytes")
    reported = raw.get("reported_free_bytes")
    if read_verified and "error_stage" not in raw and _valid_count(available) and _valid_count(reported):
        free = min(available, reported)
        enough = free >= RESERVE_BYTES
        return {
            **result,
            "evidence": "live",
            "available_bytes": available,
            "reported_free_bytes": reported,
            "free_tb": free / 1_000_000_000_000,
            "reserve_status": "met" if enough else "below",
            "status": "Share read verified, reserve met" if enough else "Share read verified, below reserve",
            "detail": "The reserve uses the lower of volume free space and space available to the SMB account.",
        }
    stage = raw.get("error_stage")
    if not isinstance(stage, str) or stage not in _FAILURES:
        stage = "space" if read_verified else "worker"
    result.update(
        status="Share read verified, capacity unverified" if read_verified else "Share read unverified",
        detail=_FAILURES[stage],
        error_stage=stage,
    )
    code = raw.get("error_code")
    if type(code) is int and 0 < code < 2**32:
        result["error_code"] = code
        result["detail"] += f" Windows error {code}."
    return result


def probe_share(share: str, secret: bytes) -> dict:
    if not is_pmi_service_account():
        return _summarize({"error_stage": "identity"})
    try:
        root = validate_storage_share(share)
    except ValueError:
        return _summarize({"error_stage": "configuration"})
    if not isinstance(secret, bytes) or not 0 < len(secret) <= _MAX_CIPHERTEXT:
        return _summarize({"error_stage": "credential"})
    try:
        result = subprocess.run(
            [sys.executable, "-I", "-B", str(Path(__file__).resolve()), root],
            input=secret, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=_TIMEOUT_SECONDS, creationflags=subprocess.CREATE_NO_WINDOW, check=True,
        )
        raw = json.loads(result.stdout)
        if not isinstance(raw, dict):
            raw = {"error_stage": "worker"}
    except subprocess.TimeoutExpired:
        raw = {"error_stage": "timeout"}
    except (OSError, ValueError, subprocess.CalledProcessError):
        raw = {"error_stage": "worker"}
    return _summarize(raw)


if __name__ == "__main__":
    # Isolated mode omits the script directory. Import the vault only from the app.
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    try:
        raw = _measure(sys.argv[1], sys.stdin.buffer.read(_MAX_CIPHERTEXT + 1))
    except Exception:
        raw = {"error_stage": "worker"}
    print(json.dumps(raw))
